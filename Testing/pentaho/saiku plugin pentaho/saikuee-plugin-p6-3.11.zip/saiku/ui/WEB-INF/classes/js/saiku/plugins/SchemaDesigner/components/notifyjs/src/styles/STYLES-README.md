* Styles in CoffeeScript go here, which will be compiled into `dist/styles`
* Styles in JavaScript can go straight in `dist/styles/`