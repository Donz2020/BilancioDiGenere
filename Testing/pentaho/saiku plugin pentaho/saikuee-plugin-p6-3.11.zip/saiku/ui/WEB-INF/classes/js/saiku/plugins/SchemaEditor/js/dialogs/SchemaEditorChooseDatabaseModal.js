/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2016
 */

var SchemaEditorChooseDatabaseModal = Modal.extend({
  type: 'schema-editor',

  message: '<form onsubmit="return false;">' +
             '<div class="form-group">' +
               '<label for="databases-available" class="i18n">Databases Available:</label>' +
               '<select class="form-control" id="databases-available"></select>' +
             '</div>' +
             '<div class="form-group">' +
               '<label for="database-schema" class="i18n">Database Schema:</label>' +
               '<select class="form-control" id="database-schema"></select>' +
             '</div>' +
           '</form>',

  buttons: [
    { text: 'Save', method: 'save' },
    { text: 'Cancel', method: 'close' }
  ],

  events: {
    'click  .dialog_footer a'     : 'call',
    'change #databases-available' : 'get_schema'
  },

  initialize: function(args) {
    _.extend(this, args);

    this.options.title = 'Choose Database';

    this.bind('open', function() {
      var $optionsDB = this.option_template({ data: this.databases });

      this.$el.find('#databases-available').empty();
      this.$el.find('#databases-available').append($optionsDB);
    });
  },

  option_template: function(obj) {
    return _.template(
      '<option value="">-- Select --</option>' +
      '<% _.each(obj.data, function(entry) { %>' +
        '<option value="<%= entry %>"><%= entry %></option>' +
      '<% }); %>'
    )(obj);
  },

  get_schema: function(event) {
    event.preventDefault();

    var self = this;
    var $currentTarget = $(event.currentTarget);
    var database = $currentTarget.val();
    var dbSchemas = new SchemaEditorDBSchemaModel({}, { database: database });
    var $optionsSchema;

    dbSchemas.fetch({
      success: function(model, response) {
        $optionsSchema = self.option_template({ data: model.attributes });
        self.$el.find('#database-schema').empty();
        self.$el.find('#database-schema').append($optionsSchema);
      },
      error: function(model, response) {
        console.error(response.statusText);
      }
    });
  },

  save: function(event) {
    event.preventDefault();

    var self = this;
    var database = this.$el.find('#databases-available').val();
    var schema = this.$el.find('#database-schema').val();
    var dbTables = new SchemaEditorDBTablesModel({}, { database: database, schema: schema });
    var alertMsg = '';

    if (_.isEmpty(database)) {
      alertMsg += '<li>You have to choose a Database Available!</li>';
    }
    if (_.isEmpty(schema)) {
      alertMsg += '<li>You have to choose a Database Schema!</li>';
    }
    if (alertMsg !== '') {
      (new WarningModal({
          title: '<span class="i18n">Required Fields</span>',
          message: '<ul>' + alertMsg + '</ul>'
      })).render().open();

      this.$el.parents('.ui-dialog').find('.ui-dialog-title').text('Choose Database');
    }
    else {
      dbTables.fetch({
        success: function(model, response, options) {
          (new SchemaEditor({
            action: self.action,
            dataSourceName: self.dataSourceName,
            data: { database: database, schema: schema, tables: response.tables },
            connectionType: 'DB'
          })).render().open();

          self.$el.dialog('close');
        },
        error: function(model, response) {
          console.error(response.statusText);
        }
      });
    }
  }
});
