/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2016
 */

var SchemaEditorDBConnectionModel = Backbone.Model.extend({
  url: 'api/database'
});

var SchemaEditorDBSchemaModel = Backbone.Model.extend({
  url: function() {
    return 'api/database/' + this.database;
  },

  initialize: function(args, options) {
    if (options) {
      this.database = options.database;
    }
  },

  parse: function(response) {
    var len = response.schema.length;
    var schema = [];

    for (var i = 0; i < len; i++) {
      schema.push(response.schema[i].name);
    }

    return schema;
  }
});

var SchemaEditorDBTablesModel = Backbone.Model.extend({
  url: function() {
    return 'api/database/' + this.database + '/' + this.schema;
  },

  initialize: function(args, options) {
    if (options) {
      this.database = options.database;
      this.schema = options.schema;
    }
  }
});

var SchemaEditorDBColumnsModel = Backbone.Model.extend({
  url: function() {
    return 'api/database/' + this.database + '/' + this.schema + '/' + this.table;
  },

  initialize: function(args, options) {
    this.schemaMock = new SchemaEditorSchemaMock();

    if (options && options.dialog) {
      this.dialog = options.dialog;
      this.database = options.database;
      this.schema = options.schema;
      this.table = options.table;
    }
  },

  parse: function(response) {
    var tableColumns = {};

    Saiku.ui.block('<span class="i18n">Loading...</span>');

    if (this.dialog) {
      tableColumns[this.table] = response.column;
      this.setDBSchemaModel(tableColumns);
      this.dialog.populate(tableColumns);
    }
  },

  setDBSchemaModel: function(data) {
    var schema = this.schemaMock.getSchema(data);
    var tablesCollection = this.dialog.schemaModel.get('tables');
    var dimensionsCollection = this.dialog.schemaModelClone.get('dimensions');
    var dimensionCollection;

    // console.log(data);

    for (var i = 0, iLen = schema.tables.length; i < iLen; i++) {
      // Add table
      tablesCollection.add(new SchemaEditorTablesModel(schema.tables[i]));
    }

    for (var j = 0, jLen = schema.dimensions.length; j < jLen; j++) {
      // Add dimension
      dimensionsCollection.add(new SchemaEditorDimensionsModel(schema.dimensions[j].dimension));

      for (var k = 0, kLen = schema.dimensions[j].attributes.length; k < kLen; k++) {
        // Add attribute
        dimensionCollection = dimensionsCollection.get(schema.dimensions[j].dimension.id);
        dimensionCollection.attribute.add(new SchemaEditorAttributeModel(schema.dimensions[j].attributes[k]));
      }
    }
  }
});

var SchemaEditorDBMetadataEditModel = Backbone.Model.extend({
  url: function() {
    return 'api/mondrian2/' + this.dataSourceName;
  },

  initialize: function(args, options) {
    this.schemaMock = new SchemaEditorSchemaMock();

    if (options && options.dialog) {
      this.dialog = options.dialog;
      this.dataSourceName = options.dataSourceName;
    }
  },

  parse: function(response) {
    this.setDBSchemaModel(response);

    Saiku.ui.block('<span class="i18n">Loading...</span>');

    if (this.dialog) {
      this.dialog.populate_edit(response);
    }
  },

  setDBSchemaModel: function(data) {
    var schema = data;
    var factTable = schema.factTable;
    var tablesCollection = this.dialog.schemaModel.get('tables');
    var measuresCollection = this.dialog.schemaModel.get('measures');
    var dimensionsCollection = this.dialog.schemaModel.get('dimensions');
    var dimensionCollection;
    var hierarchyCollection;

    // console.log(data);

    tablesCollection.reset();
    measuresCollection.reset();
    dimensionsCollection.reset();

    this.dialog.schemaModel.set({ factTable: factTable });
    this.dialog.select_current_fact_table(factTable);

    for (var i = 0, iLen = schema.tables.length; i < iLen; i++) {
      // Add table
      tablesCollection.add(new SchemaEditorTablesModel(schema.tables[i]));
    }

    for (var j = 0, jLen = schema.measures.length; j < jLen; j++) {
      // Add measure
      measuresCollection.add(new SchemaEditorMeasuresModel(schema.measures[j]));
    }

    for (var k = 0, kLen = schema.dimensions.length; k < kLen; k++) {
      // Add dimension
      var dataSchemaDimension = this.schemaMock.schemaDimension(schema.dimensions[k]);
      dimensionsCollection.add(new SchemaEditorDimensionsModel(dataSchemaDimension.dimension));

      for (var l = 0, lLen = dataSchemaDimension.attributes.length; l < lLen; l++) {
        // Add attribute
        dimensionCollection = dimensionsCollection.get(dataSchemaDimension.dimension.id);
        dimensionCollection.attribute.add(new SchemaEditorAttributeModel(dataSchemaDimension.attributes[l]));
      }

      for (var m = 0, mLen = schema.dimensions[k].hierarchy.length; m < mLen; m++) {
        // Add hierarchy
        var dataSchemaHierarchy = this.schemaMock.schemaHierarchy(schema.dimensions[k].hierarchy[m]);
        dimensionCollection = dimensionsCollection.get(schema.dimensions[k].id);
        dimensionCollection.hierarchy.add(new SchemaEditorHierarchyModel(dataSchemaHierarchy));

        for (var n = 0, nLen = schema.dimensions[k].hierarchy[m].level.length; n < nLen; n++) {
          // Add level
          var dataSchemaLevel = this.schemaMock.schemaLevel(schema.dimensions[k].hierarchy[m].level[n]);
          hierarchyCollection = dimensionCollection.hierarchy.get(schema.dimensions[k].hierarchy[m].id);
          hierarchyCollection.level.add(new SchemaEditorLevelModel(dataSchemaLevel));
        }
      }
    }
  }
});
