/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2016
 */

var SchemaEditorSchemaModel = Backbone.Model.extend({
  url: 'api/mondrian2',

  defaults: {
    apiVersion: '1.0',
    dataSourceName: '',
    tables: [],
    factTable: '',
    measures: [],
    dimensions: []
  }
});

// Tables

var SchemaEditorTablesCollection = Backbone.Collection.extend({
  model: SchemaEditorTablesModel,

  getData: function(tableName) {
    if (this.findWhere({ name: tableName })) {
      return this.findWhere({ name: tableName }).toJSON();
    }
    else {
      return false;
    }
  }
});

var SchemaEditorTablesModel = Backbone.Model.extend({
  defaults: {
    name: '',
    sourceTable: '',
    keyColumn: '',
    linkTarget: '',
    linkTargetColumn: ''
  }
});

// Measures

var SchemaEditorMeasuresCollection = Backbone.Collection.extend({
  model: SchemaEditorMeasuresModel
});

var SchemaEditorMeasuresModel = Backbone.Model.extend({
  defaults: {
    name: '',
    properties: {
      sourceColumn: '',
      defaultAggregation: ''
    }
  }
});

// Dimensions

var SchemaEditorDimensionsCollection = Backbone.Collection.extend({
  model: SchemaEditorDimensionsModel
});

var SchemaEditorDimensionsModel = Backbone.Model.extend({
  defaults: {
    name: '',
    key: '',
    factLinkColumn: ''
  },

  initialize: function() {
    this.attribute = new SchemaEditorAttributeCollection();
    this.attribute.parent = this;
    this.hierarchy = new SchemaEditorHierarchyCollection();
    this.hierarchy.parent = this;
  },

  toJSON: function() {
    var attr = _.clone(this.attributes);
    attr.attribute = this.attribute;
    attr.hierarchy = this.hierarchy;
    return attr;
  }
});

var SchemaEditorAttributeCollection = Backbone.Collection.extend({
  model: SchemaEditorAttributeModel
});

var SchemaEditorAttributeModel = Backbone.Model.extend({
  defaults: {
    name: '',
    sourceTable: '',
    sourceColumn: '',
    visible: true
  }
});

var SchemaEditorHierarchyCollection = Backbone.Collection.extend({
  model: SchemaEditorHierarchyModel
});

var SchemaEditorHierarchyModel = Backbone.Model.extend({
  defaults: {
    name: ''
  },

  initialize: function() {
    this.level = new SchemaEditorLevelCollection();
    this.level.parent = this;
  },

  toJSON: function() {
    var attr = _.clone(this.attributes);
    attr.level = this.level;
    return attr;
  }
});

var SchemaEditorLevelCollection = Backbone.Collection.extend({
  model: SchemaEditorLevelModel
});

var SchemaEditorLevelModel = Backbone.Model.extend({
  defaults: {
    name: '',
    properties: {
      sourceTable: '',
      sourceColumn: '',
      uniqueMember: false,
      ordinalTable: '',
      ordinalColumn: ''
    }
  }
});
