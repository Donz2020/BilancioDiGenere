/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2016
 */

var SchemaEditor = Modal.extend({
  type: 'schema-editor',

  message: '<div class="schema-editor">' +
             '<div class="sidebar" style="width: 280px;">' +
                '<h3 class="i18n">Available</h3>' +
                '<div class="group-btn-available">' +
                  '<ul>' +
                    '<li class="separator"><a href="#delete_table" class="i18n button btn-delete-table disabled pull-right" original-title="Delete Table Link"></a></li>' +
                    '<li class="separator"><a href="#show_auto_populate" class="i18n button btn-auto-populate pull-right" original-title="Auto Populate"></a></li>' +
                    '<li><a href="#show_auto_star_schema" class="i18n button btn-star-schema pull-right" original-title="Star Schema"></a></li>' +
                  '</ul>' +
                '</div>' +
                '<div class="sidebar_inner dimension_tree tables-available">' +
                  '<ul class="parent_tables"></ul>' +
                '</div>' +
             '</div>' +
             '<div class="sidebar" style="width: 360px;">' +
                '<h3 class="i18n">Analysis</h3>' +
                '<div class="group-btn-analysis">' +
                  '<ul>' +
                    '<li><a href="#show_clear_model" class="i18n btn-clear-model button pull-right" original-title="Clear Model" data-action="add"></a></li>' +
                    '<li><a href="#call_show_delete" class="i18n btn-delete-item button disabled pull-right" original-title="Delete Item"></a></li>' +
                    '<li class="separator"><a href="#show_form_fact_table" class="i18n btn-fact-table button pull-right" original-title="Fact Table"></a></li>' +
                    '<li><a href="#show_form_level" class="i18n btn-level button disabled pull-right" original-title="Add Level" data-action="add"></a></li>' +
                    '<li><a href="#show_form_hierarchy" class="i18n btn-hierarchy button disabled pull-right" original-title="Add Hierarchy" data-action="add"></a></li>' +
                    '<li><a href="#show_form_attribute" class="i18n btn-attribute button disabled pull-right" original-title="Add Attribute" data-action="add"></a></li>' +
                    '<li><a href="#show_form_dimension" class="i18n btn-dimension button disabled pull-right" original-title="Add Dimension" data-action="add"></a></li>' +
                    '<li><a href="#show_form_measure" class="i18n btn-measure button disabled pull-right" original-title="Add Measure" data-action="add"></a></li>' +
                  '</ul>' +
                '</div>' +
                '<div class="analysis-container">' +
                  '<div class="sidebar_inner measure_tree measure-container">' +
                    '<ul>' +
                      '<li>' +
                        '<span class="root expand sprite"></span>' +
                        '<a href="javascript:void(0);" class="folder_collapsed sprite root-measures" title="Measures">' +
                          '<span class="i18n">Measures</span>' +
                        '</a>' +
                        '<ul class="parent_measures"></ul>' +
                      '</li>' +
                    '</ul>' +
                  '</div>' +
                  '<div class="sidebar_inner dimension_tree dimension-container">' +
                    '<ul>' +
                      '<li>' +
                        '<span class="root expand sprite"></span>' +
                        '<a href="javascript:void(0);" class="folder_collapsed sprite root-dimensions" title="Dimensions">' +
                          '<span class="i18n">Dimensions</span>' +
                        '</a>' +
                        '<ul class="parent_dimensions"></ul>' +
                      '</li>' +
                    '</ul>' +
                  '</div>' +
                '</div>' +
             '</div>' +
             '<div class="sidebar" style="width: 280px;">' +
                '<h3><span class="i18n">Properties</span></h3>' +
                '<div class="sidebar_inner form-properties"></div>' +
             '</div>' +
           '</div>',

  buttons: [
    // { text: 'Debug', method: 'debug' },
    { text: 'Save', method: 'save' },
    { text: 'Cancel', method: 'close' }
  ],

  events: {
    'click  .dialog_footer a'        : 'call',
    'click  .collapsed'              : 'select',
    'click  .expand'                 : 'select',
    // 'click .folder_collapsed'        : 'select',
    'click  .folder_expanded'        : 'select',
    'click  .btn-star-schema'        : 'show_auto_star_schema',
    'click  .btn-auto-populate'      : 'show_auto_populate',
    'click  .root-measures'          : 'show_form_root_measure',
    'click  .root-dimensions'        : 'show_form_root_dimension',
    'click  .btn-measure'            : 'show_form_measure',
    'click  .btn-dimension'          : 'show_form_dimension',
    'click  .btn-attribute'          : 'show_form_attribute',
    'click  .btn-hierarchy'          : 'show_form_hierarchy',
    'click  .btn-level'              : 'show_form_level',
    'click  .btn-fact-table'         : 'show_form_fact_table',
    'click  .btn-delete-table'       : 'call_show_delete',
    'click  .btn-delete-item'        : 'call_show_delete',
    'click  .btn-clear-model'        : 'show_clear_model',
    'click  .btn-cancel'             : 'form_cancel',
    'click  .add-fact-table'         : 'add_fact_table',
    'click  .edit-fact-table'        : 'edit_fact_table',
    'change #table-link-target'      : 'select_link_target',
    'click  .table-item'             : 'show_form_table',
    'click  .add-table'              : 'add_table',
    'click  .edit-table'             : 'edit_table',
    'click  .delete-table'           : 'show_delete_table',
    'change #measure-source-column'  : 'select_measure_source_column',
    'click  .measure-item'           : 'show_form_measure',
    'click  .add-measure'            : 'add_measure',
    'click  .edit-measure'           : 'edit_measure',
    'click  .delete-measure'         : 'show_delete_measure',
    'click  .dimension-item'         : 'show_form_dimension',
    'click  .add-dimension'          : 'add_dimension',
    'click  .edit-dimension'         : 'edit_dimension',
    'click  .delete-dimension'       : 'show_delete_dimension',
    'change #attribute-source-table' : 'select_attribute_source_table',
    'click  .attribute-item'         : 'show_form_attribute',
    'click  .add-attribute'          : 'add_attribute',
    'click  .edit-attribute'         : 'edit_attribute',
    'click  .delete-attribute'       : 'show_delete_attribute',
    'click  .hierarchy-item'         : 'show_form_hierarchy',
    'click  .add-hierarchy'          : 'add_hierarchy',
    'click  .edit-hierarchy'         : 'edit_hierarchy',
    'click  .delete-hierarchy'       : 'show_delete_hierarchy',
    'change #level-source-table'     : 'select_level_source_table',
    'click  .level-item'             : 'show_form_level',
    'click  .add-level'              : 'add_level',
    'click  .edit-level'             : 'edit_level',
    'click  .delete-level'           : 'show_delete_level'
  },

  BASE_URL: '../../../js/saiku/plugins/SchemaEditor',
  MODAL_TITLE: 'Schema Editor',

  initialize: function(args) {
    _.extend(this, args);

    this.options.title = this.MODAL_TITLE;
    this.action = this.action || 'add';
    this.schemaType = 'default';
    this.SchemaEditorData = {};
    this.columnDimensionId = [];

    this.bind('open', function() {
      var percTop = (((($('body').height() - 600) / 2) * 100) / $('body').height());
      var percLeft = (((($('body').width() - 1000) / 2) * 100) / $('body').width());

      if (this.action === 'edit') {
        this.$el.find('.dialog_footer').find('a[href="#save"]').text('Update');
      }

      this.$el.dialog('option', 'position', 'center');
      this.$el.parents('.ui-dialog').css({
        width: '1000px',
        height: '600px',
        top: percTop + '%',
        left: percLeft + '%'
      });

      // Show tooltip
      $('a.button[original-title]').tipsy();

      Saiku.ui.block('<span class="i18n">Loading...</span>');

      this.schemaModel = new SchemaEditorSchemaModel({
        apiVersion: '1.0',
        dataSourceName: this.dataSourceName,
        tables: new SchemaEditorTablesCollection(),
        measures: new SchemaEditorMeasuresCollection(),
        dimensions: new SchemaEditorDimensionsCollection()
      });

      this.schemaModelClone = new SchemaEditorSchemaModel({
        apiVersion: '1.0',
        dataSourceName: this.dataSourceName,
        tables: new SchemaEditorTablesCollection(),
        measures: new SchemaEditorMeasuresCollection(),
        dimensions: new SchemaEditorDimensionsCollection()
      });

      if (this.connectionType === 'DB') {
        this.db_table_fetch();
      }
      else if (this.connectionType === 'CSV') {
        this.csv_table_fetch();
      }
    });
  },

  detach_event: function(eventName) {
    this.events[eventName] = undefined;
    this.delegateEvents(this.events);
  },

  attach_event: function(eventName, methodName) {
    this.events[eventName] = methodName;
    this.delegateEvents(this.events);
  },

  prepare: function(className) {
    this.$el.find('.' + className)
      .css({ backgroundColor: '#ccc' })
      .delay(1000)
      .animate({ backgroundColor: '#fff' }, 'slow');
  },

  set_modal_title: function(name) {
    var title = name || this.MODAL_TITLE;

    this.$el.parents('.ui-dialog').find('.ui-dialog-title').text(title);
  },

  capitalize: function(str) {
    if (_.isString(str)) {
      str = str.replace(/[^a-zA-Z 0-9]/gi, ' ');
      return str.charAt(0).toUpperCase() + str.substring(1).toLowerCase();
    }
  },

  select: function(event) {
    var $target = $(event.target).parent().find('span.sprite');

    if ($target.hasClass('root')) {
      $target.find('a').toggleClass('folder_collapsed').toggleClass('folder_expand');
      $target.toggleClass('collapsed').toggleClass('expand');
      $target.parents('li').find('ul').children('li').toggle();
    }
    else if ($target.hasClass('sub-root-dimension')) {
      $(event.target).parent().find('.sub-root-dimension').toggleClass('collapsed').toggleClass('expand');
      $target.closest('li.parent_dimension').find('ul').find('li.parent_attribute, li.parent_hierarchy').toggle();
    }
    else if ($target.hasClass('sub-root-hierarchy')) {
      $(event.target).parent().find('.sub-root-hierarchy').toggleClass('collapsed').toggleClass('expand');
      $target.closest('li.parent_hierarchy').find('ul').find('li.parent_level').toggle();
    }

    this.disabled_btn_icons();
    this.unselect_current_selected_item();
    this.$el.find('.form-properties').empty();

    return false;
  },

  db_table_fetch: function() {
    var len = this.data.tables.length;

    for (var i = 0; i < len; i++) {
      var dbTableColumns = new SchemaEditorDBColumnsModel({}, {
        dialog: this,
        database: this.data.database,
        schema: this.data.schema,
        table: this.data.tables[i]
      });

      dbTableColumns.fetch();
    }
  },

  db_table_fetch_edit: function() {
    var dbMetadataEdit = new SchemaEditorDBMetadataEditModel({}, {
      dialog: this,
      dataSourceName: this.dataSourceName
    });

    dbMetadataEdit.fetch();
  },

  csv_table_fetch: function() {
    var csvMetadata = new SchemaEditorCSVMetadataModel({}, {
      dialog: this,
      dataSourceName: this.dataSourceName
    });

    csvMetadata.fetch();
  },

  csv_table_fetch_edit: function() {
    var csvMetadataEdit = new SchemaEditorCSVMetadataEditModel({}, {
      dialog: this,
      dataSourceName: this.dataSourceName
    });

    csvMetadataEdit.fetch();
  },

  table_template: function(data) {
    return _.template(
      '<% _.each(obj.repoObjects, function(table, tableName) { %>' +
        '<li class="table">' +
          '<span class="root collapsed sprite"></span>' +
          '<a href="javascript:void(0);" class="folder_collapsed sprite table-item" title="<%= tableName %>">' +
            '<%= tableName %>' +
          '</a>' +
          '<ul class="columns_available">' +
            '<% _.each(table, function(column) { %>' +
              '<li class="table-column hide" data-id="<%= column.id %>" data-table="<%= tableName %>" data-nullable="<%= column.nullable %>" data-type="<%= column.type %>">' +
                '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<%= column.name %>' +
              '</li>' +
            '<% }); %>' +
          '</ul>' +
        '</li>' +
      '<% }); %>'
    )({ repoObjects: data });
  },

  measure_template: function(data) {
    return _.template(
      '<% _.each(obj.repoObjects, function(value) { %>' +
        '<li class="measure-item <%= value.spriteexpanded ? "hide" : "" %>" data-id="<%= value.id %>" data-table="<%= value.properties.sourceTable %>" data-action="edit">' +
          '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="' + this.BASE_URL + '/images/dialog_measure.png" width="16" height="16">' +
          '&nbsp;<span class="measure-item-name"><%= value.name %></span>' +
        '</li>' +
      '<% }); %>'
    )({ repoObjects: data });
  },

  dimension_template: function(data) {
    return _.template(
      '<% _.each(obj.repoObjects, function(dimension) { %>' +
        '<li class="parent_dimension">' +
          '<span class="sub-root-dimension collapsed sprite"></span>' +
          '<a href="#show_form_dimension" class="folder_collapsed sprite dimension-item" title="<%= dimension.name %>" data-id="<%= dimension.id %>" data-action="edit">' +
            '<img src="' + this.BASE_URL + '/images/dialog_dimension.png" width="16" height="16" /> <span class="dimension-item-name"><%= dimension.name %></span>' +
          '</a>' +
          '<ul class="attribute_tree">' +
            '<% _.each(dimension.attribute.toJSON(), function(attribute) { %>' +
              '<li class="parent_attribute hide">' +
                '<span class="sub-root-attribute collapsed sprite hide"></span>' +
                '<a href="#show_form_attribute" class="folder_collapsed sprite attribute-item" title="<%= attribute.name %>" data-iddimension="<%= dimension.id %>" data-id="<%= attribute.id %>" data-action="edit">' +
                  '<img src="' + this.BASE_URL + '/images/dialog_attribute.png" width="16" height="16" /> <span class="attribute-item-name"><%= attribute.name %></span>' +
                '</a>' +
              '</li>' +
            '<% }); %>' +
          '</ul>' +
          '<ul class="hierarchy_tree">' +
            '<% _.each(dimension.hierarchy.toJSON(), function(hierarchy) { %>' +
              '<li class="parent_hierarchy hide">' +
                '<span class="sub-root-hierarchy collapsed sprite"></span>' +
                '<a href="#show_form_hierarchy" class="folder_collapsed sprite hierarchy-item" title="<%= hierarchy.name %>" data-iddimension="<%= dimension.id %>" data-id="<%= hierarchy.id %>" data-action="edit">' +
                  '<img src="' + this.BASE_URL + '/images/dialog_hierarchy.png" width="16" height="16" /> <span class="hierarchy-item-name"><%= hierarchy.name %></span>' +
                '</a>' +
                '<ul class="level_tree">' +
                  '<% _.each(hierarchy.level.toJSON(), function(level) { %>' +
                    '<li class="parent_level hide">' +
                      '<span class="sub-root-level collapsed sprite hide"></span>' +
                      '<a href="#show_form_level" class="folder_collapsed sprite level-item" title="<%= level.name %>" data-iddimension="<%= dimension.id %>" data-idhierarchy="<%= hierarchy.id %>" data-id="<%= level.id %>" data-action="edit">' +
                        '<img src="' + this.BASE_URL + '/images/dialog_level.png" width="16" height="16" /> <span class="level-item-name"><%= level.name %></span>' +
                      '</a>' +
                    '</li>' +
                  '<% }); %>' +
                '</ul>' +
              '</li>' +
            '<% }); %>' +
          '</ul>' +
        '</li>' +
      '<% }); %>'
    )({ repoObjects: data });
  },

  dimension_tree_template: function(data) {
    return _.template(
      '<% _.each(obj.repoObjects, function(data) { %>' +
        '<li class="parent_dimension <%= data.spriteexpanded ? "hide" : "" %>">' +
          '<span class="sub-root-dimension collapsed sprite"></span>' +
          '<a href="#show_form_dimension" class="folder_collapsed sprite dimension-item" title="<%= data.dimension.name %>" data-id="<%= data.dimension.id %>" data-action="edit">' +
            '<img src="' + this.BASE_URL + '/images/dialog_dimension.png" width="16" height="16" /> <span class="dimension-item-name"><%= data.dimension.name %></span>' +
          '</a>' +
          '<ul class="attribute_tree">' +
            '<li class="parent_attribute hide">' +
              '<span class="sub-root-attribute collapsed sprite hide"></span>' +
              '<a href="#show_form_attribute" class="folder_collapsed sprite attribute-item" title="<%= data.attribute.name %>" data-iddimension="<%= data.dimension.id %>" data-id="<%= data.attribute.id %>" data-action="edit">' +
                '<img src="' + this.BASE_URL + '/images/dialog_attribute.png" width="16" height="16" /> <span class="attribute-item-name"><%= data.attribute.name %></span>' +
              '</a>' +
            '</li>' +
          '</ul>' +
          '<ul class="hierarchy_tree"></ul>' +
        '</li>' +
      '<% }); %>'
    )({ repoObjects: data });
  },

  attribute_template: function(data) {
    return _.template(
      '<% _.each(obj.repoObjects, function(data) { %>' +
        '<li class="parent_attribute <%= data.spriteexpanded ? "hide" : "" %>">' +
          '<span class="sub-root-attribute collapsed sprite hide"></span>' +
          '<a href="#show_form_attribute" class="folder_collapsed sprite attribute-item" title="<%= data.attribute.name %>" data-iddimension="<%= data.dimension.id %>" data-id="<%= data.attribute.id %>" data-action="edit">' +
            '<img src="' + this.BASE_URL + '/images/dialog_attribute.png" width="16" height="16" /> <span class="attribute-item-name"><%= data.attribute.name %></span>' +
          '</a>' +
        '</li>' +
      '<% }); %>'
    )({ repoObjects: data });
  },

  hierarchy_template: function(data) {
    return _.template(
      '<% _.each(obj.repoObjects, function(data) { %>' +
        '<li class="parent_hierarchy <%= data.spriteexpanded ? "hide" : "" %>">' +
          '<span class="sub-root-hierarchy collapsed sprite"></span>' +
          '<a href="#show_form_hierarchy" class="folder_collapsed sprite hierarchy-item" title="<%= data.hierarchy.name %>" data-iddimension="<%= data.dimension.id %>" data-id="<%= data.hierarchy.id %>" data-action="edit">' +
            '<img src="' + this.BASE_URL + '/images/dialog_hierarchy.png" width="16" height="16" /> <span class="hierarchy-item-name"><%= data.hierarchy.name %></span>' +
          '</a>' +
          '<ul class="level_tree">' +
            '<li class="parent_level hide">' +
              '<span class="sub-root-level collapsed sprite hide"></span>' +
              '<a href="#show_form_level" class="folder_collapsed sprite level-item" title="<%= data.level.name %>" data-iddimension="<%= data.dimension.id %>" data-idhierarchy="<%= data.hierarchy.id %>" data-id="<%= data.level.id %>" data-action="edit">' +
                '<img src="' + this.BASE_URL + '/images/dialog_level.png" width="16" height="16" /> <span class="level-item-name"><%= data.level.name %></span>' +
              '</a>' +
            '</li>' +
          '</ul>' +
        '</li>' +
      '<% }); %>'
    )({ repoObjects: data });
  },

  level_template: function(data) {
    return _.template(
      '<% _.each(obj.repoObjects, function(data) { %>' +
        '<li class="parent_level <%= data.spriteexpanded ? "hide" : "" %>">' +
          '<span class="sub-root-level collapsed sprite hide"></span>' +
          '<a href="#show_form_level" class="folder_collapsed sprite level-item" title="<%= data.level.name %>" data-iddimension="<%= data.dimension.id %>" data-idhierarchy="<%= data.hierarchy.id %>" data-id="<%= data.level.id %>" data-action="edit">' +
            '<img src="' + this.BASE_URL + '/images/dialog_level.png" width="16" height="16" /> <span class="level-item-name"><%= data.level.name %></span>' +
          '</a>' +
        '</li>' +
      '<% }); %>'
    )({ repoObjects: data });
  },

  data_default_agg: function(type) {
    if (type === 'Integer|Double') {
      return (
        [
          { name: 'SUM', value: 'sum' },
          { name: 'AVERAGE', value: 'average' },
          { name: 'MINIMUM', value: 'minimum' },
          { name: 'MAXIMUM', value: 'maximum' },
          { name: 'COUNT', value: 'count' },
          { name: 'COUNT_DISTINCT', value: 'count-distinct' }
        ]
      );
    }
    else {
      return (
        [
          { name: 'COUNT', value: 'count' },
          { name: 'COUNT_DISTINCT', value: 'count-distinct' }
        ]
      );
    }
  },

  option_template: function(obj) {
    return _.template(
      '<option value=""><span class="i18n">-- Select --</span></option>' +
      '<% _.each(obj.data, function(entry) { %>' +
        '<option value="<%= entry.value ? entry.value : entry.name %>">' +
          '<%= entry.name %>' +
        '</option>' +
      '<% }); %>'
    )(obj);
  },

  option_table_template: function(data) {
    return _.template(
      '<option value=""><span class="i18n">-- Select --</span></option>' +
      '<% _.each(obj.repoObjects, function(value, key) { %>' +
        '<option value="<%= key %>"><%= key %></option>' +
      '<% }); %>'
    )({ repoObjects: data });
  },

  option_column_template: function(data) {
    return _.template(
      '<option value=""><span class="i18n">-- Select --</span></option>' +
      '<% _.each(obj.repoObjects, function(value, key) { %>' +
        '<option value="<%= value.name %>" data-id="<%= value.id %>" data-nullable="<%= value.nullable %>" data-type="<%= value.type %>">' +
          '<%= value.name %>' +
        '</option>' +
      '<% }); %>'
    )({ repoObjects: data });
  },

  optgroup_column_template: function(data) {
    return _.template(
      '<option value=""><span class="i18n">-- Select --</span></option>' +
      '<% _.each(obj.repoObjects, function(value, key) { %>' +
        '<optgroup label="<%= key %>">' +
          '<% _.each(value, function(value, key) { %>' +
            '<option value="<%= value.name %>" data-id="<%= value.id %>" data-nullable="<%= value.nullable %>" data-type="<%= value.type %>">' +
              '<%= value.name %>' +
            '</option>' +
          '<% }); %>' +
        '</optgroup>' +
      '<% }); %>'
    )({ repoObjects: data });
  },

  form_fact_table_template: function(obj) {
    return _.template(
      '<form onsubmit="return false;">' +
        '<div class="form-group">' +
          '<label for="fact-table"><span class="i18n">Fact Table:</span></label>' +
          '<select class="form-control" id="fact-table"></select>' +
        '</div>' +
        '<div class="btn-group">' +
          '<% if (obj.action === "add") { %>' +
            '<button type="button" class="btn btn-default add-fact-table"><span class="i18n">Add</span></button>' +
          '<% } else { %>' +
            '<button type="button" class="btn btn-default edit-fact-table" data-id="<%= obj.id %>"><span class="i18n">Update</span></button>' +
            '<button type="button" class="btn btn-default btn-cancel"><span class="i18n">Cancel</span></button>' +
          '<% } %>' +
        '</div>' +
      '</form>'
    )(obj);
  },

  form_table_template: function(obj) {
    return _.template(
      '<form onsubmit="return false;">' +
        '<div class="form-group">' +
          '<label for="table-key-column"><span class="i18n">Key Column:</span></label>' +
          '<select class="form-control" id="table-key-column"></select>' +
        '</div>' +
        '<div class="form-group">' +
          '<label for="table-link-target"><span class="i18n">Link Target:</span></label>' +
          '<select class="form-control" id="table-link-target"></select>' +
        '</div>' +
        '<div class="form-group">' +
          '<label for="table-link-target-column"><span class="i18n">Link Target Column:</span></label>' +
          '<select class="form-control" id="table-link-target-column" disabled></select>' +
        '</div>' +
        '<div class="btn-group">' +
          '<% if (obj.action === "add") { %>' +
            '<button type="button" class="btn btn-default add-table" data-table="<%= obj.table %>"><span class="i18n">Add</span></button>' +
            '<button type="button" class="btn btn-default btn-cancel"><span class="i18n">Cancel</span></button>' +
          '<% } else { %>' +
            '<button type="button" class="btn btn-default edit-table" data-id="<%= obj.id %>" data-table="<%= obj.table %>"><span class="i18n">Update</span></button>' +
            '<button type="button" class="btn btn-danger delete-table" data-id="<%= obj.id %>" data-table="<%= obj.table %>"><span class="i18n">Delete</span></button>' +
            '<button type="button" class="btn btn-default btn-cancel"><span class="i18n">Cancel</span></button>' +
          '<% } %>' +
        '</div>' +
      '</form>'
    )(obj);
  },

  form_measure_template: function(obj) {
    return _.template(
      '<form onsubmit="return false;">' +
        '<div class="form-group">' +
          '<label for="measure-name"><span class="i18n">Measure Name:</span></label>' +
          '<input type="text" class="form-control" id="measure-name" value="<%= obj.name %>">' +
        '</div>' +
        '<div class="form-group">' +
          '<label for="measure-source-column"><span class="i18n">Source Column:</span></label>' +
          '<select class="form-control" id="measure-source-column"></select>' +
        '</div>' +
        '<div class="form-group">' +
          '<label for="measure-default-agg"><span class="i18n">Default Aggregation:</span></label>' +
          '<select class="form-control" id="measure-default-agg" disabled></select>' +
        '</div>' +
        '<div class="btn-group">' +
          '<% if (obj.action === "add") { %>' +
            '<button type="button" class="btn btn-default add-measure"><span class="i18n">Add</span></button>' +
            '<button type="button" class="btn btn-default btn-cancel"><span class="i18n">Cancel</span></button>' +
          '<% } else { %>' +
            '<button type="button" class="btn btn-default edit-measure" data-id="<%= obj.id %>"><span class="i18n">Update</span></button>' +
            '<button type="button" class="btn btn-danger delete-measure" data-id="<%= obj.id %>"><span class="i18n">Delete</span></button>' +
            '<button type="button" class="btn btn-default btn-cancel"><span class="i18n">Cancel</span></button>' +
          '<% } %>' +
        '</div>' +
      '</form>'
    )(obj);
  },

  form_dimension_template: function(obj) {
    return _.template(
      '<form onsubmit="return false;">' +
        '<div class="form-group">' +
          '<label for="dimension-name"><span class="i18n">Dimension Name:</span></label>' +
          '<input type="text" class="form-control" id="dimension-name" value="<%= obj.name %>">' +
        '</div>' +
        '<div class="form-group">' +
          '<label for="dimension-key"><span class="i18n">Attribute:</span></label>' +
          '<select class="form-control" id="dimension-key" disabled></select>' +
        '</div>' +
        '<div class="form-group">' +
          '<label for="dimension-fact-link-column"><span class="i18n">Fact Link Column:</span></label>' +
          '<select class="form-control" id="dimension-fact-link-column"></select>' +
        '</div>' +
        '<div class="btn-group">' +
          '<% if (obj.action === "add") { %>' +
            '<button type="button" class="btn btn-default add-dimension"><span class="i18n">Add</span></button>' +
            '<button type="button" class="btn btn-default btn-cancel"><span class="i18n">Cancel</span></button>' +
          '<% } else { %>' +
            '<button type="button" class="btn btn-default edit-dimension" data-id="<%= obj.id %>"><span class="i18n">Update</span></button>' +
            '<button type="button" class="btn btn-danger delete-dimension" data-id="<%= obj.id %>"><span class="i18n">Delete</span></button>' +
            '<button type="button" class="btn btn-default btn-cancel"><span class="i18n">Cancel</span></button>' +
          '<% } %>' +
        '</div>' +
      '</form>'
    )(obj);
  },

  form_attribute_template: function(obj) {
    return _.template(
      '<form onsubmit="return false;">' +
        '<div class="form-group">' +
          '<label for="attribute-name"><span class="i18n">Attribute Name:</span></label>' +
          '<input type="text" class="form-control" id="attribute-name" value="<%= obj.name %>">' +
        '</div>' +
        '<div class="form-group">' +
          '<label for="attribute-source-table"><span class="i18n">Source Table:</span></label>' +
          '<select class="form-control" id="attribute-source-table"></select>' +
        '</div>' +
        '<div class="form-group">' +
          '<label for="attribute-source-column"><span class="i18n">Source Column:</span></label>' +
          '<select class="form-control" id="attribute-source-column" disabled></select>' +
        '</div>' +
        '<div class="checkbox">' +
          '<label>' +
            '<input type="checkbox" id="attribute-visible" checked> <span class="i18n">Visible</span>' +
          '</label>' +
        '</div>' +
        '<div class="btn-group">' +
          '<% if (obj.action === "add") { %>' +
            '<button type="button" class="btn btn-default add-attribute" data-iddimension="<%= obj.iddimension %>"><span class="i18n">Add</span></button>' +
            '<button type="button" class="btn btn-default btn-cancel"><span class="i18n">Cancel</span></button>' +
          '<% } else { %>' +
            '<button type="button" class="btn btn-default edit-attribute" data-iddimension="<%= obj.iddimension %>" data-id="<%= obj.id %>"><span class="i18n">Update</span></button>' +
            '<button type="button" class="btn btn-danger delete-attribute" data-iddimension="<%= obj.iddimension %>" data-id="<%= obj.id %>"><span class="i18n">Delete</span></button>' +
            '<button type="button" class="btn btn-default btn-cancel"><span class="i18n">Cancel</span></button>' +
          '<% } %>' +
        '</div>' +
      '</form>'
    )(obj);
  },

  form_hierarchy_template: function(obj) {
    return _.template(
      '<form onsubmit="return false;">' +
        '<div class="form-group">' +
          '<label for="hierarchy-name"><span class="i18n">Hierarchy Name:</span></label>' +
          '<input type="text" class="form-control" id="hierarchy-name" value="<%= obj.name %>">' +
        '</div>' +
        '<div class="btn-group">' +
          '<% if (obj.action === "add") { %>' +
            '<button type="button" class="btn btn-default add-hierarchy" data-iddimension="<%= obj.iddimension %>"><span class="i18n">Add</span></button>' +
            '<button type="button" class="btn btn-default btn-cancel"><span class="i18n">Cancel</span></button>' +
          '<% } else { %>' +
            '<button type="button" class="btn btn-default edit-hierarchy" data-iddimension="<%= obj.iddimension %>" data-id="<%= obj.id %>"><span class="i18n">Update</span></button>' +
            '<button type="button" class="btn btn-danger delete-hierarchy" data-iddimension="<%= obj.iddimension %>" data-id="<%= obj.id %>"><span class="i18n">Delete</span></button>' +
            '<button type="button" class="btn btn-default btn-cancel"><span class="i18n">Cancel</span></button>' +
          '<% } %>' +
        '</div>' +
      '</form>'
    )(obj);
  },

  form_level_template: function(obj) {
    return _.template(
      '<form onsubmit="return false;">' +
        '<div class="form-group">' +
          '<label for="level-name"><span class="i18n">Level Name:</span></label>' +
          '<input type="text" class="form-control" id="level-name" value="<%= obj.name %>">' +
        '</div>' +
        '<div class="form-group">' +
          '<label for="level-source-table"><span class="i18n">Source Table:</span></label>' +
          '<select class="form-control" id="level-source-table"></select>' +
        '</div>' +
        '<div class="form-group">' +
          '<label for="level-source-column"><span class="i18n">Source Column:</span></label>' +
          '<select class="form-control" id="level-source-column" disabled></select>' +
        '</div>' +
        '<div class="checkbox">' +
          '<label>' +
            '<input type="checkbox" id="level-unique-members"> <span class="i18n">Contains only unique members</span>' +
          '</label>' +
        '</div>' +
        '<div class="form-group">' +
          '<label for="level-ordinal-column"><span class="i18n">Ordinal Column:</span></label>' +
          '<select class="form-control" id="level-ordinal-column"></select>' +
        '</div>' +
        // '<div class="form-group">' +
        //   '<label for="geography-type"><span class="i18n">Geography Type:</span></label>' +
        //   '<select class="form-control" id="geography-type"></select>' +
        // '</div>' +
        '<div class="btn-group">' +
          '<% if (obj.action === "add") { %>' +
            '<button type="button" class="btn btn-default add-level" data-iddimension="<%= obj.iddimension %>" data-idhierarchy="<%= obj.idhierarchy %>"><span class="i18n">Add</span></button>' +
            '<button type="button" class="btn btn-default btn-cancel"><span class="i18n">Cancel</span></button>' +
          '<% } else { %>' +
            '<button type="button" class="btn btn-default edit-level" data-iddimension="<%= obj.iddimension %>" data-idhierarchy="<%= obj.idhierarchy %>" data-id="<%= obj.id %>"><span class="i18n">Update</span></button>' +
            '<button type="button" class="btn btn-danger delete-level" data-iddimension="<%= obj.iddimension %>" data-idhierarchy="<%= obj.idhierarchy %>" data-id="<%= obj.id %>"><span class="i18n">Delete</span></button>' +
            '<button type="button" class="btn btn-default btn-cancel"><span class="i18n">Cancel</span></button>' +
          '<% } %>' +
        '</div>' +
      '</form>'
    )(obj);
  },

  disabled_btn_icons: function() {
    this.$el.find('.btn-measure, .btn-dimension, .btn-attribute,' +
      '.btn-hierarchy, .btn-level, .btn-delete-item, .btn-delete-table').addClass('disabled');
  },

  unselect_current_selected_item: function() {
    this.$el.find('.selected').removeClass('selected');
  },

  select_current_fact_table: function(factTable) {
    this.$el.find('.parent_tables')
      .find('a[title="' + factTable + '"]')
      .html('<img src="' + this.BASE_URL + '/images/fact_table.png" width="16" height="16" /> ' + factTable);
  },

  unselect_current_fact_table: function(oldFactTable) {
    this.$el.find('.parent_tables')
      .find('a[title="' + oldFactTable + '"]')
      .text(oldFactTable);
  },

  unselect_column_id: function(column) {
    var regexp = /_id|-id| id|_id_|-id-|id_|id-|id /i;

    if (!!column.match(regexp)) {
      this.columnDimensionId.push(column);

      return false;
    }
    else {
      return column;
    }
  },

  has_fact_table: function(data) {
    var schemaEditorData = _.clone(data);

    _.each(data, function(value, key) {
      if (!key.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_FACT_TABLE)) {
        delete schemaEditorData[key];
      }
    });

    return schemaEditorData;
  },

  has_dimension_table: function(data) {
    var schemaEditorData = _.clone(data);

    _.each(data, function(value, key) {
      if (!key.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_DIMENSION_TABLE)) {
        delete schemaEditorData[key];
      }
    });

    return schemaEditorData;
  },

  has_measure_column: function(column) {
    if (!!column.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_COLUMN)) {
      return column;
    }
    else {
      return false;
    }
  },

  replaceMeasureAggregationColumn: function(columnName) {
    var measureName;
    var measureRegexp;
    var measureAggRegexp;

    if (!!columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_COLUMN) &&
        !!columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_AGGREGATION_COLUMN)) {

      measureRegexp = columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_COLUMN);
      measureAggRegexp = columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_AGGREGATION_COLUMN);
      measureName = Saiku.replaceString(measureRegexp[0], '', columnName);
      measureName = Saiku.replaceString(measureAggRegexp[0], '', measureName);

      return measureName;
    }
    else if (!!columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_COLUMN)) {
      measureRegexp = columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_COLUMN);
      measureName = Saiku.replaceString(measureRegexp[0], '', columnName);

      return measureName;
    }
    else {
      return columnName;
    }
  },

  getMeasureAggregationColumn: function(columnName, type) {
    var regexp = /Integer|INT|BIGINT|SMALLINT|DECIMAL|Double/i;
    var agg = {
      '_sum': 'sum',
      '_avg': 'average',
      '_min': 'minimum',
      '_max': 'maximum',
      '_count': 'count',
      '_count_distinct': 'count-distinct'
    };
    var measureAggRegexp;

    if (!!columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_COLUMN) &&
        !!columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_AGGREGATION_COLUMN)) {

      measureAggRegexp = columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_AGGREGATION_COLUMN);

      return agg[measureAggRegexp[0]];
    }
    else {
      return !!type.match(regexp) ? 'sum' : 'count';
    }
  },

  form_cancel: function(event) {
    event.preventDefault();
    this.disabled_btn_icons();
    this.unselect_current_selected_item();
    this.$el.find('.form-properties').empty();
  },

  populate: function(data) {
    var measuresData = this.schemaModel.get('measures').toJSON();
    var dimensionsData = this.schemaModel.get('dimensions').toJSON();
    var key = _.keys(data);
    var $tables = this.table_template(data);
    var $measures = this.measure_template(measuresData);
    var $dimensions = this.dimension_template(dimensionsData);

    // console.log(data);
    // console.log(JSON.stringify(this.schemaModel.toJSON()));

    // if (this.action === 'add' && this.connectionType === 'DB') {
    if (this.connectionType === 'DB') {
      this.SchemaEditorData[key] = data[key];
      this.$el.find('.parent_measures, .parent_dimensions').empty();
    }
    else if (this.connectionType === 'CSV') {
      this.SchemaEditorData = data;
      this.$el.find('.parent_tables, .parent_measures, .parent_dimensions').empty();
    }

    // this.schemaModelClone.attributes.measures = this.schemaModel.get('measures').clone();
    // this.schemaModelClone.attributes.dimensions = this.schemaModel.get('dimensions').clone();
    // this.schemaModelDimensionsClone = JSON.stringify(this.schemaModel.get('dimensions').toJSON());
    this.schemaModelDimensionsClone = JSON.stringify(this.schemaModelClone.get('dimensions').toJSON());

    this.$el.find('.parent_tables').append($tables);

    if (this.action === 'add') {
      // this.$el.find('.parent_measures').append($measures);
      // this.$el.find('.parent_dimensions').append($dimensions);

      // TODO: show form just in add mode
      this.show_form_fact_table();
      this.prepare('form-properties');
    }

    // this.draggable_column();
    // this.droppable_column_measure_root();
    // this.droppable_column_dimension_root();
    // this.droppable_column_attribute_item();
    // this.droppable_column_hierarchy_item();

    if (this.action === 'edit' && this.connectionType === 'DB') {
      Saiku.ui.block('<span class="i18n">Loading...</span>');
      this.db_table_fetch_edit();
    }
    else if (this.action === 'edit' && this.connectionType === 'CSV') {
      Saiku.ui.block('<span class="i18n">Loading...</span>');
      this.csv_table_fetch_edit();
    }

    Saiku.ui.unblock();
  },

  populate_edit: function(data) {
    var measuresData = this.schemaModel.get('measures').toJSON();
    var dimensionsData = this.schemaModel.get('dimensions').toJSON();
    var $measures = this.measure_template(measuresData);
    var $dimensions = this.dimension_template(dimensionsData);

    // console.log(data);
    // console.log(JSON.stringify(this.schemaModel.toJSON()));

    this.$el.find('.parent_measures, .parent_dimensions').empty();
    this.$el.find('.parent_measures').append($measures);
    this.$el.find('.parent_dimensions').append($dimensions);

    this.draggable_column();
    this.droppable_column_measure_root();
    this.droppable_column_dimension_root();
    this.droppable_column_attribute_item();
    this.droppable_column_hierarchy_item();

    Saiku.ui.unblock();
  },

  set_clone_model: function() {
    var tableSize = _.size(this.SchemaEditorData);
    var factTable = this.schemaModel.get('factTable');
    var factTableCapitalize = this.capitalize(factTable);
    var factTableColumn = this.SchemaEditorData[factTable];
    var schema = JSON.parse(this.schemaModelDimensionsClone);
    var measuresCollection = this.schemaModel.get('measures');
    var dimensionsCollection = this.schemaModel.get('dimensions');
    var schemaMock = new SchemaEditorSchemaMock();
    var dimensionCollection;
    var hierarchyCollection;

    measuresCollection.reset();
    dimensionsCollection.reset();

    for (var m = 0, mLen = factTableColumn.length; m < mLen; m++) {
      if (this.has_measure_column(factTableColumn[m].name) || this.unselect_column_id(factTableColumn[m].name)) {
        var dataSchemaMeasure = schemaMock.schemaMeasure(factTableColumn[m].name);
        measuresCollection.add(new SchemaEditorMeasuresModel(dataSchemaMeasure));
      }
    }

    for (var i = 0, iLen = schema.length; i < iLen; i++) {
      if (tableSize === 1 || factTableCapitalize !== schema[i].name) {
        for (var a = 0, aLen = schema[i].attribute.length; a < aLen; a++) {
          if (_.contains(this.columnDimensionId, schema[i].attribute[a].sourceColumn)) {
            // Add dimension
            var dataSchemaDimension = schemaMock.schemaDimension(schema[i]);
            dimensionsCollection.add(new SchemaEditorDimensionsModel(dataSchemaDimension.dimension));

            for (var j = 0, jLen = dataSchemaDimension.attributes.length; j < jLen; j++) {
              // Add attribute
              dimensionCollection = dimensionsCollection.get(dataSchemaDimension.dimension.id);
              dimensionCollection.attribute.add(new SchemaEditorAttributeModel(dataSchemaDimension.attributes[j]));
            }

            dimensionCollection.set({
              key: schema[i].attribute[a].name,
              factLinkColumn: schema[i].attribute[a].sourceColumn
            });

            for (var k = 0, kLen = schema[i].hierarchy.length; k < kLen; k++) {
              // Add hierarchy
              var dataSchemaHierarchy = schemaMock.schemaHierarchy(schema[i].hierarchy[k]);
              dimensionCollection = dimensionsCollection.get(schema[i].id);
              dimensionCollection.hierarchy.add(new SchemaEditorHierarchyModel(dataSchemaHierarchy));

              for (var x = 0, xLen = schema[i].hierarchy[k].level.length; x < xLen; x++) {
                // Add level
                var dataSchemaLevel = schemaMock.schemaLevel(schema[i].hierarchy[k].level[x]);
                hierarchyCollection = dimensionCollection.hierarchy.get(schema[i].hierarchy[k]);
                hierarchyCollection.level.add(new SchemaEditorLevelModel(dataSchemaLevel));
              }
            }
          }
        }
      }
    }
  },

  show_auto_star_schema: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);

    if (!($currentTarget.hasClass('disabled'))) {
      (new WarningModal({
        title: '<span class="i18n">Star Schema</span>',
        message: '<span class="i18n">Would you like to populate this model with default dimensions and measures using <b>star schema</b>?</span>',
        okay: this.auto_star_schema,
        okayobj: this
      })).render().open();

      this.set_modal_title();
    }
  },

  auto_star_schema: function(args) {
    var $tables = args.table_template(args.SchemaEditorData);
    var oldFactTable = args.schemaModel.get('factTable');

    args.$el.find('.parent_tables').empty().append($tables);
    args.unselect_current_fact_table(oldFactTable);
    args.schemaModel.set({ factTable: '' });
    args.schemaType = 'star';
    args.clear_model(args);
    args.show_form_fact_table();
    args.prepare('form-properties');
  },

  show_auto_populate: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);

    if (!($currentTarget.hasClass('disabled'))) {
      (new WarningModal({
        title: '<span class="i18n">Auto Populate</span>',
        message: '<span class="i18n">Would you like to populate this model with default dimensions and measures?</span>',
        okay: this.auto_populate,
        okayobj: this
      })).render().open();

      this.set_modal_title();
    }
  },

  auto_populate: function(args) {
    var isSpriteCollapsedMeasure = args.$el.find('.measure-container').find('.root.sprite').hasClass('collapsed');
    var isSpriteCollapsedDimension = args.$el.find('.dimension-container').find('.root.sprite').hasClass('collapsed');
    var factTable = args.schemaModel.get('factTable');
    var $tables = args.table_template(args.SchemaEditorData);
    var measuresData;
    var dimensionsData;
    var $measures;
    var $dimensions;

    args.disabled_btn_icons();
    args.unselect_current_selected_item();
    args.$el.find('.form-properties').empty();
    args.set_clone_model();

    measuresData = args.schemaModel.get('measures').toJSON();
    dimensionsData = args.schemaModel.get('dimensions').toJSON();

    $measures = args.measure_template(measuresData);
    $dimensions = args.dimension_template(dimensionsData);

    args.$el.find('.parent_tables, .parent_measures, .parent_dimensions').empty();
    args.$el.find('.parent_tables').append($tables);
    args.$el.find('.parent_measures').append($measures);
    args.$el.find('.parent_dimensions').append($dimensions);

    if (isSpriteCollapsedMeasure) {
      args.$el.find('.measure-container').find('.root.sprite').toggleClass('collapsed').toggleClass('expand');
      args.$el.find('.measure-container').find('ul.parent_measures').children('li').toggle();
      args.$el.find('.measure-container').find('ul.parent_measures').children('li').show();
    }

    if (isSpriteCollapsedDimension) {
      args.$el.find('.dimension-container').find('.root.sprite').toggleClass('collapsed').toggleClass('expand');
      args.$el.find('.dimension-container').find('ul.parent_measures').children('li').toggle();
      args.$el.find('.dimension-container').find('ul.parent_measures').children('li').show();
    }

    args.select_current_fact_table(factTable);
    args.draggable_column();
    args.droppable_column_measure_root();
    args.droppable_column_dimension_root();
    args.droppable_column_attribute_item();
    args.droppable_column_hierarchy_item();
  },

  draggable_column: function() {
    var self = this;
    var zindex = 10;

    this.$el.find('.parent_tables')
      .find('.table')
      .find('.columns_available')
      .find('.table-column').draggable({
      cancel      : '.not-draggable',
      helper      : 'clone',
      opacity     : 0.60,
      placeholder : 'placeholder',
      scroll      : false,
      tolerance   : 'touch',
      cursorAt    : { top: 10, left: 85 },
      start: function(event, ui) {
        var tableColumn = $(ui.helper).text().replace(/\s+/, '');

        self.disabled_btn_icons();
        self.unselect_current_selected_item();
        self.$el.find('.form-properties').empty();
        $(ui.helper).text(tableColumn);
      }
    });
  },

  droppable_column_measure_root: function() {
    var self = this;

    this.$el.find('.measure-container').droppable({
      hoverClass: 'over',
      drop: function(event, ui) {
        var isSpriteExpanded = self.$el.find('.measure-container').find('.root.sprite').hasClass('collapsed');
        var factTable = self.schemaModel.get('factTable');
        var measuresCollection = self.schemaModel.get('measures');
        var tableName = $(ui.draggable).data('table');
        var columnName = $(ui.draggable).text().replace(/\s+/, '');
        var type = $(ui.draggable).data('type');
        var data = [];
        var $measures;

        if (tableName === factTable) {
          data.push({
            id: _.uniqueId('id_measure_'),
            name: self.capitalize(self.replaceMeasureAggregationColumn(columnName)),
            properties: {
              sourceTable: tableName,
              sourceColumn: columnName,
              defaultAggregation: self.getMeasureAggregationColumn(columnName, type)
            }
          });

          measuresCollection.add(new SchemaEditorMeasuresModel(data[0]));

          data[0].spriteexpanded = isSpriteExpanded;
          $measures = self.measure_template(data);

          self.$el.find('.parent_measures').append($measures);

          // console.log(JSON.stringify(self.schemaModel.toJSON()));
        }
        else {
          (new WarningModal({
            title: '<span class="i18n">Warning</span>',
            message: '<h3>Just drop a column for measure if is of Fact Table!</h3>'
          })).render().open();

          this.set_modal_title();
        }
      }
    });
  },

  droppable_column_dimension_root: function() {
    var self = this;

    this.$el.find('.dimension-container').droppable({
      hoverClass: 'over',
      drop: function(event, ui) {
        var isSpriteExpanded = self.$el.find('.dimension-container').find('.root.sprite').hasClass('collapsed');
        var dimensionsCollection = self.schemaModel.get('dimensions');
        var tableName = $(ui.draggable).data('table');
        var columnName = $(ui.draggable).text().replace(/\s+/, '');
        var data = [];
        var dimensionCollection;
        var $dimensions;

        if (!(self.$el.find('.attribute_tree').hasClass('over-attribute')) &&
            !(self.$el.find('.parent_hierarchy').hasClass('over-hierarchy'))) {
          data.push({
            dimension: {
              id: _.uniqueId('id_dimension_'),
              name: self.capitalize(tableName)
            },
            attribute: {
              id: _.uniqueId('id_attr_'),
              name: self.capitalize(columnName),
              sourceTable: tableName,
              sourceColumn: columnName,
              visible: true
            }
          });

          // Add dimension
          dimensionsCollection.add(new SchemaEditorDimensionsModel(data[0].dimension));

          // Add attribute
          dimensionCollection = dimensionsCollection.get(data[0].dimension.id);
          dimensionCollection.attribute.add(new SchemaEditorAttributeModel(data[0].attribute));

          data[0].spriteexpanded = isSpriteExpanded;
          $dimensions = self.dimension_tree_template(data);

          self.$el.find('.parent_dimensions').append($dimensions);
          self.droppable_column_attribute_item();
          self.droppable_column_hierarchy_item();

          // console.log(JSON.stringify(self.schemaModel.toJSON()));
        }
      }
    });
  },

  droppable_column_attribute_item: function() {
    var self = this;

    this.$el.find('.attribute_tree').droppable({
      hoverClass: 'over-attribute',
      drop: function(event, ui) {
        var $target = $(event.target);
        var isSpriteExpanded = $target.find('.sub-root-dimension.sprite').hasClass('collapsed');
        var dimensionsCollection = self.schemaModel.get('dimensions');
        var tableName = $(ui.draggable).data('table');
        var columnName = $(ui.draggable).text().replace(/\s+/, '');
        var id_dimension = $target.find('.attribute-item').data('iddimension');
        var data = [];
        var dimensionCollection;
        var $attribute;

        data.push({
          dimension: {
            id: id_dimension
          },
          attribute: {
            id: _.uniqueId('id_attr_'),
            name: self.capitalize(columnName),
            sourceTable: tableName,
            sourceColumn: columnName,
            visible: true
          }
        });

        // Add attribute
        dimensionCollection = dimensionsCollection.get(id_dimension);
        dimensionCollection.attribute.add(new SchemaEditorAttributeModel(data[0].attribute));

        data[0].spriteexpanded = isSpriteExpanded;
        $attribute = self.attribute_template(data);

        $target.find('.attribute-item')
          .closest('.parent_dimension')
          .find('.attribute_tree')
          .append($attribute);

        // console.log(JSON.stringify(self.schemaModel.toJSON()));
      }
    });
  },

  droppable_column_hierarchy_item: function() {
    var self = this;

    this.$el.find('.parent_hierarchy').droppable({
      hoverClass: 'over-hierarchy',
      drop: function(event, ui) {
        var $target = $(event.target);
        var isSpriteExpanded = $target.find('.sub-root-hierarchy.sprite').hasClass('collapsed');
        var dimensionsCollection = self.schemaModel.get('dimensions');
        var tableName = $(ui.draggable).data('table');
        var columnName = $(ui.draggable).text().replace(/\s+/, '');
        var id_dimension = $target.find('.hierarchy-item').data('iddimension');
        var id_hierarchy = $target.find('.hierarchy-item').data('id');
        var data = [];
        var dimensionCollection;
        var hierarchyCollection;
        var $level;

        data.push({
          dimension: {
            id: id_dimension
          },
          hierarchy: {
            id: id_hierarchy
          },
          level: {
            id: _.uniqueId('id_level_'),
            name: self.capitalize(columnName),
            properties: {
              sourceTable: tableName,
              sourceColumn: columnName,
              uniqueMember: false,
              ordinalTable: '',
              ordinalColumn: ''
            }
          }
        });

        dimensionCollection = dimensionsCollection.get(id_dimension);
        hierarchyCollection = dimensionCollection.hierarchy.get(id_hierarchy);
        hierarchyCollection.level.add(new SchemaEditorLevelModel(data[0].level));

        data[0].spriteexpanded = isSpriteExpanded;
        $level = self.level_template(data);


        $target.find('.hierarchy-item')
          .closest('.parent_hierarchy')
          .find('.level_tree')
          .append($level);

        // console.log(JSON.stringify(self.schemaModel.toJSON()));
      }
    });
  },

  select_link_target: function(event) {
    if (event && _.isObject(event)) {
      event.preventDefault();
    }

    var $currentTarget = $(event.currentTarget);
    var val = $currentTarget.val() || event;
    var $options = this.option_column_template(this.SchemaEditorData[val]);

    if (val && _.isString(val)) {
      this.$el.find('#table-link-target-column').empty();
      this.$el.find('#table-link-target-column').prop('disabled', false);
      this.$el.find('#table-link-target-column').append($options);
    }
    else {
      this.$el.find('#table-link-target-column').empty();
      this.$el.find('#table-link-target-column').prop('disabled', true);
    }
  },

  select_measure_source_column: function(event) {
    if (event && _.isObject(event)) {
      event.preventDefault();
    }

    var $currentTarget = $(event.currentTarget);
    var val = $currentTarget.val() || event;

    if (val && _.isString(val)) {
      var type = this.$el.find('#measure-source-column option[value="' + val + '"]').data('type');
      var regexp = /Integer|INT|BIGINT|SMALLINT|DECIMAL|Double/i;
      var dataDefaultAgg;
      var $optionsDefaultAgg;

      if (!!type.match(regexp)) {
        dataDefaultAgg = this.data_default_agg('Integer|Double');
      }
      else {
        dataDefaultAgg = this.data_default_agg('String');
      }

      $optionsDefaultAgg = this.option_template({ data: dataDefaultAgg });

      this.$el.find('#measure-default-agg').empty();
      this.$el.find('#measure-default-agg').prop('disabled', false);
      this.$el.find('#measure-default-agg').append($optionsDefaultAgg);
    }
    else {
      this.$el.find('#measure-default-agg').empty();
      this.$el.find('#measure-default-agg').prop('disabled', true);
    }
  },

  select_attribute_source_table: function(event) {
    if (event && _.isObject(event)) {
      event.preventDefault();
    }

    var $currentTarget = $(event.currentTarget);
    var val = $currentTarget.val() || event;
    var $options = this.option_column_template(this.SchemaEditorData[val]);

    if (val && _.isString(val)) {
      this.$el.find('#attribute-source-column').empty();
      this.$el.find('#attribute-source-column').prop('disabled', false);
      this.$el.find('#attribute-source-column').append($options);
    }
    else {
      this.$el.find('#attribute-source-column').empty();
      this.$el.find('#attribute-source-column').prop('disabled', true);
    }
  },

  select_level_source_table: function(event) {
    if (event && _.isObject(event)) {
      event.preventDefault();
    }

    var $currentTarget = $(event.currentTarget);
    var val = $currentTarget.val() || event;
    var $options = this.option_column_template(this.SchemaEditorData[val]);

    if (val && _.isString(val)) {
      this.$el.find('#level-source-column').empty();
      this.$el.find('#level-source-column').prop('disabled', false);
      this.$el.find('#level-source-column').append($options);
    }
    else {
      this.$el.find('#level-source-column').empty();
      this.$el.find('#level-source-column').prop('disabled', true);
    }
  },

  show_form_root_measure: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var isSpriteExpanded = $currentTarget.closest('.measure-container').find('.root.sprite').hasClass('collapsed');

    this.unselect_current_selected_item();
    $currentTarget.addClass('selected');
    this.$el.find('.form-properties').empty();
    this.disabled_btn_icons();
    this.$el.find('.btn-measure').removeClass('disabled');
    this.$el.find('.btn-measure').data('spriteexpanded', isSpriteExpanded);
  },

  show_form_root_dimension: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var isSpriteExpanded = $currentTarget.closest('.dimension-container').find('.root.sprite').hasClass('collapsed');

    this.unselect_current_selected_item();
    $currentTarget.addClass('selected');
    this.$el.find('.form-properties').empty();
    this.disabled_btn_icons();
    this.$el.find('.btn-dimension').removeClass('disabled');
    this.$el.find('.btn-dimension').data('spriteexpanded', isSpriteExpanded);
  },

  show_form_fact_table: function(event) {
    if (event) {
      event.preventDefault();
    }

    var factTable = this.schemaModel.get('factTable');
    var schemaEditorData = this.has_fact_table(this.SchemaEditorData);
    var $options = this.option_table_template(this.schemaType === 'star' ? schemaEditorData : this.SchemaEditorData);
    var data = {};
    var $form;

    if (_.isEmpty(factTable)) {
      this.disabled_btn_icons();
      this.$el.find('.btn-star-schema, .btn-auto-populate, .btn-clear-model').addClass('disabled');
      this.unselect_current_selected_item();
      this.$el.find('.table-item, .root-measures, .root-dimensions').addClass('disabled');
      this.$el.find('.table-item, .root-measures, .root-dimensions').prop('disabled', true);
      this.$el.find('.dialog_footer').find('a[href="#save"]').hide();

      this.detach_event('click  .collapsed');
      this.detach_event('click  .expand');
      this.detach_event('click  .folder_expanded');

      data.action = 'add';

      $form = this.form_fact_table_template(data);
      this.$el.find('.form-properties, #fact-table').empty();
      this.$el.find('.form-properties').append($form);
      this.$el.find('#fact-table').append($options);
    }
    else {
      data.action = 'edit';
      $form = this.form_fact_table_template(data);
      this.$el.find('.form-properties, #fact-table').empty();
      this.$el.find('.form-properties').append($form);
      this.$el.find('#fact-table').append($options);
      this.$el.find('#fact-table option[value="' + factTable + '"]').prop('selected', true);
    }
  },

  show_form_table: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var tablesCollection = this.schemaModel.get('tables');
    var tableName = $currentTarget.prop('title');
    var $optionsKeyColumn = this.option_column_template(this.SchemaEditorData[tableName]);
    var $optionsLinkTarget = this.option_table_template(this.SchemaEditorData);
    var data = {};
    var $form;

    this.disabled_btn_icons();
    this.unselect_current_selected_item();
    $currentTarget.addClass('selected');

    if (tablesCollection.getData(tableName)) {
      data = tablesCollection.getData(tableName);
      data.action = 'edit';
      data.table = tableName;
      $form = this.form_table_template(data);
      this.$el.find('.btn-delete-table').removeClass('disabled');
      this.$el.find('.form-properties, #table-key-column, #table-link-target, #table-link-target-column').empty();
      this.$el.find('.form-properties').append($form);
      this.$el.find('#table-key-column').append($optionsKeyColumn);
      this.$el.find('#table-key-column option[value="' + data.keyColumn + '"]').prop('selected', true);
      this.$el.find('#table-link-target').append($optionsLinkTarget);
      this.$el.find('#table-link-target option[value="' + data.linkTarget + '"]').prop('selected', true);
      this.select_link_target(data.linkTarget);
      this.$el.find('#table-link-target-column option[value="' + data.linkTargetColumn + '"]').prop('selected', true);
    }
    else {
      data.action = 'add';
      data.table = tableName;
      $form = this.form_table_template(data);
      this.$el.find('.form-properties, #table-key-column, #table-link-target, #table-link-target-column').empty();
      this.$el.find('.form-properties').append($form);
      this.$el.find('#table-key-column').append($optionsKeyColumn);
      this.$el.find('#table-link-target').append($optionsLinkTarget);
    }
  },

  show_form_measure: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var action = $currentTarget.data('action');
    var factTable = this.schemaModel.get('factTable');
    var $optionsSourceColumn = this.option_column_template(this.SchemaEditorData[factTable]);
    var data = {};
    var $form;

    if (!($currentTarget.hasClass('disabled')) && action === 'add') {
      data.action = action;
      $form = this.form_measure_template(data);
      this.$el.find('.form-properties, #measure-source-column').empty();
      this.$el.find('.form-properties').append($form);
      this.$el.find('#measure-source-column').append($optionsSourceColumn);
    }
    else if (action === 'edit') {
      var measuresCollection = this.schemaModel.get('measures');
      var id = $currentTarget.data('id');

      this.disabled_btn_icons();
      this.$el.find('.btn-delete-item').removeClass('disabled');
      this.unselect_current_selected_item();
      $currentTarget.addClass('selected');

      data = measuresCollection.get(id).toJSON();
      data.action = action;

      $form = this.form_measure_template(data);
      this.$el.find('.form-properties, #measure-source-column').empty();
      this.$el.find('.form-properties').append($form);
      this.$el.find('#measure-source-column').append($optionsSourceColumn);
      this.$el.find('#measure-source-column option[value="' + data.properties.sourceColumn + '"]').prop('selected', true);
      this.select_measure_source_column(data.properties.sourceColumn);
      this.$el.find('#measure-default-agg option[value="' + data.properties.defaultAggregation + '"]').prop('selected', true);
    }
  },

  show_form_dimension: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var action = $currentTarget.data('action');
    var factTable = this.schemaModel.get('factTable');
    var $optionsFactLinkColumn = this.option_column_template(this.SchemaEditorData[factTable]);
    var data = {};
    var $form;
    var $optionsDimensionKey;

    if (!($currentTarget.hasClass('disabled')) && action === 'add') {
      data.action = action;
      $form = this.form_dimension_template(data);
      this.$el.find('.form-properties, #dimension-fact-link-column').empty();
      this.$el.find('.form-properties').append($form);
      this.$el.find('#dimension-fact-link-column').append($optionsFactLinkColumn);
    }
    else if (action === 'edit') {
      var isSpriteExpanded = $currentTarget.closest('.parent_dimension').find('.sub-root-dimension.sprite').hasClass('collapsed');
      var dimensionsCollection = this.schemaModel.get('dimensions');
      var id = $currentTarget.data('id');
      var attributesCollection = dimensionsCollection.get(id).attribute;

      this.disabled_btn_icons();
      this.$el.find('.btn-delete-item').removeClass('disabled');
      this.$el.find('.btn-attribute, .btn-hierarchy').removeClass('disabled');
      this.$el.find('.btn-attribute, .btn-hierarchy').data('iddimension', id);
      this.$el.find('.btn-attribute, .btn-hierarchy').data('spriteexpanded', isSpriteExpanded);
      this.unselect_current_selected_item();
      $currentTarget.addClass('selected');

      data = dimensionsCollection.get(id).toJSON();
      data.action = action;

      $form = this.form_dimension_template(data);
      this.$el.find('.form-properties, #dimension-key, #dimension-fact-link-column').empty();
      this.$el.find('.form-properties').append($form);

      if (attributesCollection && attributesCollection.length > 1) {
        this.$el.find('#dimension-key').prop('disabled', false);
        $optionsDimensionKey = this.option_template({ data: attributesCollection.toJSON() });
        this.$el.find('#dimension-key').append($optionsDimensionKey);
        this.$el.find('#dimension-key option[value="' + data.key + '"]').prop('selected', true);
      }

      this.$el.find('#dimension-fact-link-column').append($optionsFactLinkColumn);
      this.$el.find('#dimension-fact-link-column option[value="' + data.factLinkColumn + '"]').prop('selected', true);
    }
  },

  show_form_attribute: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var action = $currentTarget.data('action');
    var $optionsSourceTable = this.option_table_template(this.SchemaEditorData);
    // var $options = this.optgroup_column_template(this.SchemaEditorData);
    var data = {};
    var $form;

    if (!($currentTarget.hasClass('disabled')) && action === 'add') {
      var id_dimension = $currentTarget.data('iddimension');

      data.action = action;
      data.iddimension = id_dimension;
      $form = this.form_attribute_template(data);
      this.$el.find('.form-properties, #attribute-source-table, #attribute-source-column').empty();
      this.$el.find('.form-properties').append($form);
      this.$el.find('#attribute-source-table').append($optionsSourceTable);
      // this.$el.find('#attribute-source-column').append($options);
    }
    else if (action === 'edit') {
      var dimensionsCollection = this.schemaModel.get('dimensions');
      var id_dimension = $currentTarget.data('iddimension');
      var id_attribute = $currentTarget.data('id');
      var isVisible;

      this.disabled_btn_icons();
      this.$el.find('.btn-delete-item').removeClass('disabled');
      this.unselect_current_selected_item();
      $currentTarget.addClass('selected');

      data = dimensionsCollection.get(id_dimension).toJSON();
      data = data.attribute.get(id_attribute).toJSON();
      data.iddimension = id_dimension;

      isVisible = data.visible;

      $form = this.form_attribute_template(data);
      this.$el.find('.form-properties, #attribute-source-table, #attribute-source-column').empty();
      this.$el.find('.form-properties').append($form);
      this.$el.find('#attribute-source-table').append($optionsSourceTable);
      this.$el.find('#attribute-source-table option[value="' + data.sourceTable + '"]').prop('selected', true);
      this.select_attribute_source_table(data.sourceTable);
      // this.$el.find('#attribute-source-column').append($options);
      this.$el.find('#attribute-source-column option[value="' + data.sourceColumn + '"]').prop('selected', true);
      this.$el.find('#attribute-visible').prop('checked', isVisible);
    }
  },

  show_form_hierarchy: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var action = $currentTarget.data('action');
    var data = {};
    var $form;

    if (!($currentTarget.hasClass('disabled')) && action === 'add') {
      var id_dimension = $currentTarget.data('iddimension');

      data.action = action;
      data.iddimension = id_dimension;
      $form = this.form_hierarchy_template(data);
      this.$el.find('.form-properties').empty();
      this.$el.find('.form-properties').append($form);
    }
    else if (action === 'edit') {
      var isSpriteExpanded = $currentTarget.closest('.parent_hierarchy').find('.sub-root-hierarchy.sprite').hasClass('collapsed');
      var dimensionsCollection = this.schemaModel.get('dimensions');
      var id_dimension = $currentTarget.data('iddimension');
      var id_hierarchy = $currentTarget.data('id');

      this.disabled_btn_icons();
      this.$el.find('.btn-delete-item').removeClass('disabled');
      this.$el.find('.btn-level').removeClass('disabled');
      this.$el.find('.btn-level').data('iddimension', id_dimension);
      this.$el.find('.btn-level').data('idhierarchy', id_hierarchy);
      this.$el.find('.btn-level').data('spriteexpanded', isSpriteExpanded);
      this.unselect_current_selected_item();
      $currentTarget.addClass('selected');

      data = dimensionsCollection.get(id_dimension).toJSON();
      data = data.hierarchy.get(id_hierarchy).toJSON();
      data.iddimension = id_dimension;

      $form = this.form_hierarchy_template(data);
      this.$el.find('.form-properties').empty();
      this.$el.find('.form-properties').append($form);
    }
  },

  show_form_level: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var action = $currentTarget.data('action');
    var $optionsSourceTable = this.option_table_template(this.SchemaEditorData);
    var $options = this.optgroup_column_template(this.SchemaEditorData);
    var data = {};
    var $form;

    if (!($currentTarget.hasClass('disabled')) && action === 'add') {
      var id_dimension = $currentTarget.data('iddimension');
      var id_hierarchy = $currentTarget.data('idhierarchy');

      data.action = action;
      data.iddimension = id_dimension;
      data.idhierarchy = id_hierarchy;
      $form = this.form_level_template(data);
      this.$el.find('.form-properties, #level-source-table, #level-source-column, #level-ordinal-column').empty();
      this.$el.find('.form-properties').append($form);
      this.$el.find('#level-source-table').append($optionsSourceTable);
      // this.$el.find('#level-source-column').append($options);
      this.$el.find('#level-ordinal-column').append($options);
    }
    else if (action === 'edit') {
      var dimensionsCollection = this.schemaModel.get('dimensions');
      var id_dimension = $currentTarget.data('iddimension');
      var id_hierarchy = $currentTarget.data('idhierarchy');
      var id_level = $currentTarget.data('id');
      var isUniqueMember;

      this.disabled_btn_icons();
      this.$el.find('.btn-delete-item').removeClass('disabled');
      this.unselect_current_selected_item();
      $currentTarget.addClass('selected');

      data = dimensionsCollection.get(id_dimension).toJSON();
      data = data.hierarchy.get(id_hierarchy).toJSON();
      data = data.level.get(id_level).toJSON();
      data.iddimension = id_dimension;
      data.idhierarchy = id_hierarchy;

      isUniqueMember = data.properties.uniqueMember;

      $form = this.form_level_template(data);
      this.$el.find('.form-properties, #level-source-table, #level-source-column, #level-ordinal-column').empty();
      this.$el.find('.form-properties').append($form);
      // this.$el.find('#level-source-column').append($options);
      this.$el.find('#level-source-table').append($optionsSourceTable);
      this.$el.find('#level-source-table option[value="' + data.properties.sourceTable + '"]').prop('selected', true);
      this.select_level_source_table(data.properties.sourceTable);
      this.$el.find('#level-source-column option[value="' + data.properties.sourceColumn + '"]').prop('selected', true);
      this.$el.find('#level-unique-members').prop('checked', isUniqueMember);
      this.$el.find('#level-ordinal-column').append($options);
      // this.$el.find('#level-ordinal-column option[value="' + data.properties.ordinalColumn + '"]').prop('selected', true);
      this.$el.find('#level-ordinal-column optgroup[label="' + data.properties.ordinalTable + '"]')
        .find('option[value="' + data.properties.ordinalColumn + '"]')
        .prop('selected', true);
    }
  },

  clear_form_measure: function() {
    this.$el.find('#measure-name').val('');
    this.$el.find('#measure-source-column, #measure-default-agg').empty();
    this.$el.find('#measure-source-column, #measure-default-agg').prop('disabled', true);
  },

  clear_form_dimension: function() {
    this.$el.find('#dimension-name').val('');
    this.$el.find('#dimension-key').empty();
    this.$el.find('#dimension-key').prop('disabled', true);
    this.$el.find('#dimension-fact-link-column').prop('selectedIndex', 0);
  },

  clear_form_attribute: function() {
    this.$el.find('#attribute-name').val('');
    this.$el.find('#attribute-source-table').prop('selectedIndex', 0);
    this.$el.find('#attribute-source-column').empty();
    this.$el.find('#attribute-source-column').prop('disabled', true);
    this.$el.find('#attribute-visible').prop('checked', true);
  },

  clear_form_hierarchy: function() {
    this.$el.find('#hierarchy-name').val('');
  },

  clear_form_level: function() {
    this.$el.find('#level-name').val('');
    this.$el.find('#level-source-table').prop('selectedIndex', 0);
    this.$el.find('#level-source-column').empty();
    this.$el.find('#level-source-column').prop('disabled', true);
    this.$el.find('#level-unique-members').prop('checked', false);
    this.$el.find('#level-ordinal-column').prop('selectedIndex', 0);
  },

  add_fact_table: function(event) {
    event.preventDefault();

    var factTable = this.$el.find('#fact-table').val();
    var alertMsg = '';

    if (_.isEmpty(factTable)) {
      alertMsg += '<li>You have to choose a Fact Table!</li>';
    }
    if (alertMsg !== '') {
      (new WarningModal({
        title: '<span class="i18n">Required Fields</span>',
        message: '<ul>' + alertMsg + '</ul>'
      })).render().open();

      this.set_modal_title();
    }
    else {
      this.schemaModel.set({ factTable: factTable });

      this.disabled_btn_icons();
      this.$el.find('.btn-star-schema, .btn-auto-populate, .btn-clear-model').removeClass('disabled');
      this.unselect_current_selected_item();
      this.$el.find('.table-item, .root-measures, .root-dimensions').removeClass('disabled');
      this.$el.find('.table-item, .root-measures, .root-dimensions').prop('disabled', false);
      this.$el.find('.dialog_footer').find('a[href="#save"]').show();
      this.$el.find('.form-properties').empty();

      this.attach_event('click  .collapsed', 'select');
      this.attach_event('click  .expand', 'select');
      this.attach_event('click  .folder_expanded', 'select');

      this.draggable_column();
      this.droppable_column_measure_root();
      this.droppable_column_dimension_root();
      this.droppable_column_attribute_item();
      this.droppable_column_hierarchy_item();

      this.prepare('analysis-container');

      this.select_current_fact_table(factTable);

      // console.log(JSON.stringify(this.schemaModel.toJSON()));
    }
  },

  edit_fact_table: function(event) {
    event.preventDefault();

    var oldFactTable = this.schemaModel.get('factTable');
    var factTable = this.$el.find('#fact-table').val();
    var alertMsg = '';

    if (_.isEmpty(factTable)) {
      alertMsg += '<li>You have to choose a Fact Table!</li>';
    }
    if (alertMsg !== '') {
      (new WarningModal({
        title: '<span class="i18n">Required Fields</span>',
        message: '<ul>' + alertMsg + '</ul>'
      })).render().open();

      this.set_modal_title();
    }
    else {
      this.schemaModel.set({ factTable: factTable });
      this.$el.find('.form-properties').empty();
      this.clear_model(this);
      this.unselect_current_fact_table(oldFactTable);
      this.select_current_fact_table(factTable);

      // console.log(JSON.stringify(this.schemaModel.toJSON()));
    }
  },

  add_table: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var tablesCollection = this.schemaModel.get('tables');
    var tableName = $currentTarget.data('table');
    var tableKeyColumn = this.$el.find('#table-key-column').val();
    var tableLinkTarget = this.$el.find('#table-link-target').val();
    var tableLinkTargetColumn = this.$el.find('#table-link-target-column').val();
    var alertMsg = '';
    var data;

    if (_.isEmpty(tableKeyColumn)) {
      alertMsg += '<li>You have to choose a Key Column for the table link!</li>';
    }
    if (_.isEmpty(tableLinkTarget)) {
      alertMsg += '<li>You have to choose a Link Target for the table link!</li>';
    }
    if (_.isEmpty(tableLinkTargetColumn)) {
      alertMsg += '<li>You have to choose a Link Target Column for the table link!</li>';
    }
    if (alertMsg !== '') {
      (new WarningModal({
        title: '<span class="i18n">Required Fields</span>',
        message: '<ul>' + alertMsg + '</ul>'
      })).render().open();

      this.set_modal_title();
    }
    else {
      data = {
        id: _.uniqueId('id_table_'),
        name: tableName,
        sourceTable: tableName,
        keyColumn: tableKeyColumn,
        linkTarget: tableLinkTarget,
        linkTargetColumn: tableLinkTargetColumn
      };

      tablesCollection.add(new SchemaEditorTablesModel(data));

      this.disabled_btn_icons();
      this.unselect_current_selected_item();
      this.$el.find('.form-properties').empty();

      // console.log(JSON.stringify(this.schemaModel.toJSON()));
    }
  },

  edit_table: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var tablesCollection = this.schemaModel.get('tables');
    var id = $currentTarget.data('id');
    var tableName = $currentTarget.data('table');
    var tableKeyColumn = this.$el.find('#table-key-column').val();
    var tableLinkTarget = this.$el.find('#table-link-target').val();
    var tableLinkTargetColumn = this.$el.find('#table-link-target-column').val();
    var alertMsg = '';
    var data;

    tablesCollection = tablesCollection.get(id);

    if (_.isEmpty(tableKeyColumn)) {
      alertMsg += '<li>You have to choose a Key Column for the table link!</li>';
    }
    if (_.isEmpty(tableLinkTarget)) {
      alertMsg += '<li>You have to choose a Link Target for the table link!</li>';
    }
    if (_.isEmpty(tableLinkTargetColumn)) {
      alertMsg += '<li>You have to choose a Link Target Column for the table link!</li>';
    }
    if (alertMsg !== '') {
      (new WarningModal({
        title: '<span class="i18n">Required Fields</span>',
        message: '<ul>' + alertMsg + '</ul>'
      })).render().open();

      this.set_modal_title();
    }
    else {
      data = {
        sourceTable: tableName,
        keyColumn: tableKeyColumn,
        linkTarget: tableLinkTarget,
        linkTargetColumn: tableLinkTargetColumn
      };

      tablesCollection.set(data);

      this.disabled_btn_icons();
      this.unselect_current_selected_item();
      this.$el.find('.form-properties').empty();

      // console.log(JSON.stringify(this.schemaModel.toJSON()));
    }
  },

  show_delete_table: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var tableName = $currentTarget.data('table');

    this.id_table = $currentTarget.data('id');

    (new WarningModal({
      title: '<span class="i18n">Delete Table Link</span>',
      message: '<span class="i18n">You want to delete this table link</span> <b>' + tableName + '</b>?',
      okay: this.delete_table,
      okayobj: this
    })).render().open();

    this.set_modal_title();
  },

  delete_table: function(args) {
    var tablesCollection = args.schemaModel.get('tables');

    tablesCollection.remove(args.id_table);

    args.disabled_btn_icons();
    args.unselect_current_selected_item();
    args.$el.find('.form-properties').empty();

    // console.log(JSON.stringify(args.schemaModel.toJSON()));
  },

  add_measure: function(event) {
    event.preventDefault();

    var measuresCollection = this.schemaModel.get('measures');
    var measureName = this.$el.find('#measure-name').val();
    var measureSourceColumn = this.$el.find('#measure-source-column').val();
    var measureDefaultAgg = this.$el.find('#measure-default-agg').val();
    var alertMsg = '';
    var data = [];
    var $measures;

    if (_.isEmpty(measureName)) {
      alertMsg += '<li>The Measure Name field can not be empty!</li>';
    }
    if (_.isEmpty(measureSourceColumn)) {
      alertMsg += '<li>You have to choose a Source Column for the measure!</li>';
    }
    if (_.isEmpty(measureDefaultAgg)) {
      alertMsg += '<li>You have to choose a Format for the measure!</li>';
    }
    if (alertMsg !== '') {
      (new WarningModal({
        title: '<span class="i18n">Required Fields</span>',
        message: '<ul>' + alertMsg + '</ul>'
      })).render().open();

      this.set_modal_title();
    }
    else {
      data.push({
        id: _.uniqueId('id_measure_'),
        name: measureName,
        properties: {
          sourceColumn: measureSourceColumn,
          defaultAggregation: measureDefaultAgg
        }
      });

      measuresCollection.add(new SchemaEditorMeasuresModel(data[0]));

      data[0].spriteexpanded = this.$el.find('.btn-measure').data('spriteexpanded');
      $measures = this.measure_template(data);

      this.$el.find('.parent_measures').append($measures);
      this.clear_form_measure();

      // console.log(JSON.stringify(this.schemaModel.toJSON()));
    }
  },

  edit_measure: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var measuresCollection = this.schemaModel.get('measures');
    var id = $currentTarget.data('id');
    var measureName = this.$el.find('#measure-name').val();
    var measureSourceColumn = this.$el.find('#measure-source-column').val();
    var measureDefaultAgg = this.$el.find('#measure-default-agg').val();
    var alertMsg = '';
    var data = [];

    measuresCollection = measuresCollection.get(id);

    if (_.isEmpty(measureName)) {
      alertMsg += '<li>The Measure Name field can not be empty!</li>';
    }
    if (_.isEmpty(measureSourceColumn)) {
      alertMsg += '<li>You have to choose a Source Column for the measure!</li>';
    }
    if (_.isEmpty(measureDefaultAgg)) {
      alertMsg += '<li>You have to choose a Format for the measure!</li>';
    }
    if (alertMsg !== '') {
      (new WarningModal({
        title: '<span class="i18n">Required Fields</span>',
        message: '<ul>' + alertMsg + '</ul>'
      })).render().open();

      this.set_modal_title();
    }
    else {
      data.push({
        name: measureName,
        properties: {
          sourceColumn: measureSourceColumn,
          defaultAggregation: measureDefaultAgg
        }
      });

      measuresCollection.set(data[0]);

      this.$el.find('.parent_measures')
        .find('.measure-item.selected')
        .find('.measure-item-name')
        .text(data[0].name);

      this.disabled_btn_icons();
      this.unselect_current_selected_item();
      this.$el.find('.form-properties').empty();

      // console.log(JSON.stringify(this.schemaModel.toJSON()));
    }
  },

  show_delete_measure: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var measureName = this.$el.find('#measure-name').val();

    this.id_measure = $currentTarget.data('id');

    (new WarningModal({
      title: '<span class="i18n">Delete Measure</span>',
      message: '<span class="i18n">You want to delete this measure</span> <b>' + measureName + '</b>?',
      okay: this.delete_measure,
      okayobj: this
    })).render().open();

    this.set_modal_title();
  },

  delete_measure: function(args) {
    var measuresCollection = args.schemaModel.get('measures');

    measuresCollection.remove(args.id_measure);

    args.$el.find('.parent_measures')
      .find('.measure-item.selected')
      .remove();

    args.disabled_btn_icons();
    args.unselect_current_selected_item();
    args.$el.find('.form-properties').empty();

    // console.log(JSON.stringify(args.schemaModel.toJSON()));
  },

  add_dimension: function(event) {
    event.preventDefault();

    var dimensionsCollection = this.schemaModel.get('dimensions');
    var dimensionName = this.$el.find('#dimension-name').val();
    var dimensionFactLinkColumn = this.$el.find('#dimension-fact-link-column').val();
    var alertMsg = '';
    var data = [];
    var dimensionCollection;
    var hierarchyCollection;
    var $dimensions;

    if (_.isEmpty(dimensionName)) {
      alertMsg += '<li>The Dimension Name field can not be empty!</li>';
    }
    if (alertMsg !== '') {
      (new WarningModal({
        title: '<span class="i18n">Required Fields</span>',
        message: '<ul>' + alertMsg + '</ul>'
      })).render().open();

      this.set_modal_title();
    }
    else {
      data.push({
        dimension: {
          id: _.uniqueId('id_dimension_'),
          name: dimensionName,
          factLinkColumn: dimensionFactLinkColumn
        },
        attribute: {
          id: _.uniqueId('id_attr_'),
          name: dimensionName,
          sourceTable: '',
          sourceColumn: '',
          visible: true
        }
      });

      // Add dimension
      dimensionsCollection.add(new SchemaEditorDimensionsModel(data[0].dimension));

      // Add attribute
      dimensionCollection = dimensionsCollection.get(data[0].dimension.id);
      dimensionCollection.attribute.add(new SchemaEditorAttributeModel(data[0].attribute));

      data[0].spriteexpanded = this.$el.find('.btn-dimension').data('spriteexpanded');
      $dimensions = this.dimension_tree_template(data);

      this.$el.find('.parent_dimensions').append($dimensions);
      this.clear_form_dimension();

      this.droppable_column_attribute_item();
      this.droppable_column_hierarchy_item();

      // console.log(JSON.stringify(this.schemaModel.toJSON()));
    }
  },

  edit_dimension: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var dimensionsCollection = this.schemaModel.get('dimensions');
    var id = $currentTarget.data('id');
    var dimensionName = this.$el.find('#dimension-name').val();
    var dimensionKey = this.$el.find('#dimension-key').val();
    var dimensionFactLinkColumn = this.$el.find('#dimension-fact-link-column').val();
    var alertMsg = '';
    var data = [];

    dimensionsCollection = dimensionsCollection.get(id);

    if (_.isEmpty(dimensionName)) {
      alertMsg += '<li>The Dimension Name field can not be empty!</li>';
    }
    if (alertMsg !== '') {
      (new WarningModal({
        title: '<span class="i18n">Required Fields</span>',
        message: '<ul>' + alertMsg + '</ul>'
      })).render().open();

      this.set_modal_title();
    }
    else {
      data.push({
        name: dimensionName,
        key: dimensionKey,
        factLinkColumn: dimensionFactLinkColumn
      });

      dimensionsCollection.set(data[0]);

      this.$el.find('.parent_dimension')
        .find('.dimension-item.selected')
        .find('.dimension-item-name')
        .text(data[0].name);

      this.disabled_btn_icons();
      this.unselect_current_selected_item();
      this.$el.find('.form-properties').empty();

      // console.log(JSON.stringify(this.schemaModel.toJSON()));
    }
  },

  show_delete_dimension: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var dimensionName = this.$el.find('#dimension-name').val();

    this.id_dimension = $currentTarget.data('id');

    (new WarningModal({
      title: '<span class="i18n">Delete Dimension</span>',
      message: '<span class="i18n">You want to delete this dimension</span> <b>' + dimensionName + '</b>?',
      okay: this.delete_dimension,
      okayobj: this
    })).render().open();

    this.set_modal_title();
  },

  delete_dimension: function(args) {
    var dimensionsCollection = args.schemaModel.get('dimensions');

    dimensionsCollection.remove(args.id_dimension);

    args.$el.find('.parent_dimension')
      .find('.dimension-item.selected')
      .closest('.parent_dimension')
      .remove();

    args.disabled_btn_icons();
    args.unselect_current_selected_item();
    args.$el.find('.form-properties').empty();

    // console.log(JSON.stringify(args.schemaModel.toJSON()));
  },

  add_attribute: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var dimensionsCollection = this.schemaModel.get('dimensions');
    var attributeName = this.$el.find('#attribute-name').val();
    var attributeSourceTable = this.$el.find('#attribute-source-table').val();
    var attributeSourceColumn = this.$el.find('#attribute-source-column').val();
    var attributeVisible = this.$el.find('#attribute-visible').is(':checked');
    var id_dimension = $currentTarget.data('iddimension');
    var alertMsg = '';
    var data = [];
    var dimensionCollection;
    var $attribute;

    if (_.isEmpty(attributeName)) {
      alertMsg += '<li>The Attribute Name field can not be empty!</li>';
    }
    if (_.isEmpty(attributeSourceTable)) {
      alertMsg += '<li>You have to choose a Source Table for the attribute!</li>';
    }
    if (_.isEmpty(attributeSourceColumn)) {
      alertMsg += '<li>You have to choose a Source Column for the attribute!</li>';
    }
    if (alertMsg !== '') {
      (new WarningModal({
        title: '<span class="i18n">Required Fields</span>',
        message: '<ul>' + alertMsg + '</ul>'
      })).render().open();

      this.set_modal_title();
    }
    else {
      data.push({
        dimension: {
          id: id_dimension
        },
        attribute: {
          id: _.uniqueId('id_attr_'),
          name: attributeName,
          sourceTable: attributeSourceTable,
          sourceColumn: attributeSourceColumn,
          visible: attributeVisible
        }
      });

      // Add attribute
      dimensionCollection = dimensionsCollection.get(id_dimension);
      dimensionCollection.attribute.add(new SchemaEditorAttributeModel(data[0].attribute));

      data[0].spriteexpanded = this.$el.find('.btn-attribute').data('spriteexpanded');
      $attribute = this.attribute_template(data);

      this.$el.find('.parent_dimension')
        .find('.dimension-item.selected')
        .closest('.parent_dimension')
        .find('.attribute_tree')
        .append($attribute);
      this.clear_form_attribute();

      // console.log(JSON.stringify(this.schemaModel.toJSON()));
    }
  },

  edit_attribute: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var dimensionsCollection = this.schemaModel.get('dimensions');
    var attributeName = this.$el.find('#attribute-name').val();
    var attributeSourceTable = this.$el.find('#attribute-source-table').val();
    var attributeSourceColumn = this.$el.find('#attribute-source-column').val();
    var attributeVisible = this.$el.find('#attribute-visible').is(':checked');
    var id_dimension = $currentTarget.data('iddimension');
    var id_attribute = $currentTarget.data('id');
    var alertMsg = '';
    var data;
    var dimensionCollection;
    var attributeCollection;

    if (_.isEmpty(attributeName)) {
      alertMsg += '<li>The Attribute Name field can not be empty!</li>';
    }
    if (_.isEmpty(attributeSourceTable)) {
      alertMsg += '<li>You have to choose a Source Table for the attribute!</li>';
    }
    if (_.isEmpty(attributeSourceColumn)) {
      alertMsg += '<li>You have to choose a Source Column for the attribute!</li>';
    }
    if (alertMsg !== '') {
      (new WarningModal({
        title: '<span class="i18n">Required Fields</span>',
        message: '<ul>' + alertMsg + '</ul>'
      })).render().open();

      this.set_modal_title();
    }
    else {
      data = {
        name: attributeName,
        sourceTable: attributeSourceTable,
        sourceColumn: attributeSourceColumn,
        visible: attributeVisible
      };

      dimensionCollection = dimensionsCollection.get(id_dimension);
      attributeCollection = dimensionCollection.attribute.get(id_attribute);

      attributeCollection.set(data);

      this.$el.find('.parent_dimension')
        .find('.dimension-item')
        .closest('.parent_dimension')
        .find('.attribute_tree')
        .find('.attribute-item.selected')
        .find('.attribute-item-name')
        .text(data.name);

      this.disabled_btn_icons();
      this.unselect_current_selected_item();
      this.$el.find('.form-properties').empty();

      // console.log(JSON.stringify(this.schemaModel.toJSON()));
    }
  },

  show_delete_attribute: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var attributeName = this.$el.find('#attribute-name').val();

    this.id_dimension = $currentTarget.data('iddimension');
    this.id_attribute = $currentTarget.data('id');

    (new WarningModal({
      title: '<span class="i18n">Delete Attribute</span>',
      message: '<span class="i18n">You want to delete this attribute</span> <b>' + attributeName + '</b>?',
      okay: this.delete_attribute,
      okayobj: this
    })).render().open();

    this.set_modal_title();
  },

  delete_attribute: function(args) {
    var dimensionsCollection = args.schemaModel.get('dimensions');

    dimensionCollection = dimensionsCollection.get(args.id_dimension);
    dimensionCollection.attribute.remove(args.id_attribute);

    args.$el.find('.parent_dimension')
      .find('.dimension-item')
      .closest('.parent_dimension')
      .find('.attribute_tree')
      .find('.attribute-item.selected')
      .closest('.parent_attribute')
      .remove();

    args.disabled_btn_icons();
    args.unselect_current_selected_item();
    args.$el.find('.form-properties').empty();

    // console.log(JSON.stringify(args.schemaModel.toJSON()));
  },

  add_hierarchy: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var dimensionsCollection = this.schemaModel.get('dimensions');
    var hierarchyName = this.$el.find('#hierarchy-name').val();
    var id_dimension = $currentTarget.data('iddimension');
    var alertMsg = '';
    var data = [];
    var dimensionCollection;
    var hierarchyCollection;
    var $hierarchy;

    if (_.isEmpty(hierarchyName)) {
      alertMsg += '<li>The Hierarchy Name field can not be empty!</li>';
    }
    if (alertMsg !== '') {
      (new WarningModal({
        title: '<span class="i18n">Required Fields</span>',
        message: '<ul>' + alertMsg + '</ul>'
      })).render().open();

      this.set_modal_title();
    }
    else {
      data.push({
        dimension: {
          id: id_dimension
        },
        hierarchy: {
          id: _.uniqueId('id_hierarchy_'),
          name: hierarchyName
        },
        level: {
          id: _.uniqueId('id_level_'),
          name: hierarchyName,
          properties: {
            sourceTable: '',
            sourceColumn: '',
            uniqueMember: false,
            ordinalTable: '',
            ordinalColumn: ''
          }
        }
      });

      // Add hierarchy
      dimensionCollection = dimensionsCollection.get(id_dimension);
      dimensionCollection.hierarchy.add(new SchemaEditorHierarchyModel(data[0].hierarchy));

      // Add level
      hierarchyCollection = dimensionCollection.hierarchy.get(data[0].hierarchy.id);
      hierarchyCollection.level.add(new SchemaEditorLevelModel(data[0].level));

      data[0].spriteexpanded = this.$el.find('.btn-hierarchy').data('spriteexpanded');
      $hierarchy = this.hierarchy_template(data);

      this.$el.find('.parent_dimension')
        .find('.dimension-item.selected')
        .closest('.parent_dimension')
        .find('.hierarchy_tree')
        .append($hierarchy);

      this.clear_form_hierarchy();

      this.droppable_column_hierarchy_item();

      // console.log(JSON.stringify(this.schemaModel.toJSON()));
    }
  },

  edit_hierarchy: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var dimensionsCollection = this.schemaModel.get('dimensions');
    var hierarchyName = this.$el.find('#hierarchy-name').val();
    var id_dimension = $currentTarget.data('iddimension');
    var id_hierarchy = $currentTarget.data('id');
    var alertMsg = '';
    var data = [];
    var dimensionCollection;
    var hierarchyCollection;

    if (_.isEmpty(hierarchyName)) {
      alertMsg += '<li>The Hierarchy Name field can not be empty!</li>';
    }
    if (alertMsg !== '') {
      (new WarningModal({
        title: '<span class="i18n">Required Fields</span>',
        message: '<ul>' + alertMsg + '</ul>'
      })).render().open();

      this.set_modal_title();
    }
    else {
      data.push({
        name: hierarchyName
      });

      dimensionCollection = dimensionsCollection.get(id_dimension);
      hierarchyCollection = dimensionCollection.hierarchy.get(id_hierarchy);

      hierarchyCollection.set(data[0]);

      this.$el.find('.parent_dimension')
        .find('.dimension-item')
        .closest('.parent_dimension')
        .find('.hierarchy_tree')
        .find('.hierarchy-item.selected')
        .find('.hierarchy-item-name')
        .text(data[0].name);

      this.disabled_btn_icons();
      this.unselect_current_selected_item();
      this.$el.find('.form-properties').empty();

      // console.log(JSON.stringify(this.schemaModel.toJSON()));
    }
  },

  show_delete_hierarchy: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var hierarchyName = this.$el.find('#hierarchy-name').val();

    this.id_dimension = $currentTarget.data('iddimension');
    this.id_hierarchy = $currentTarget.data('id');

    (new WarningModal({
      title: '<span class="i18n">Delete Hierarchy</span>',
      message: '<span class="i18n">You want to delete this hierarchy</span> <b>' + hierarchyName + '</b>?',
      okay: this.delete_hierarchy,
      okayobj: this
    })).render().open();

    this.set_modal_title();
  },

  delete_hierarchy: function(args) {
    var dimensionsCollection = args.schemaModel.get('dimensions');

    dimensionCollection = dimensionsCollection.get(args.id_dimension);
    dimensionCollection.hierarchy.remove(args.id_hierarchy);

    args.$el.find('.parent_dimension')
      .find('.dimension-item')
      .closest('.parent_dimension')
      .find('.hierarchy_tree')
      .find('.hierarchy-item.selected')
      .closest('.parent_hierarchy')
      .remove();

    args.disabled_btn_icons();
    args.unselect_current_selected_item();
    args.$el.find('.form-properties').empty();

    // console.log(JSON.stringify(args.schemaModel.toJSON()));
  },

  add_level: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var dimensionsCollection = this.schemaModel.get('dimensions');
    var levelName = this.$el.find('#level-name').val();
    var levelSourceTable = this.$el.find('#level-source-table').val();
    var levelSourceColumn = this.$el.find('#level-source-column').val();
    var levelUniqueMember = this.$el.find('#level-unique-members').is(':checked');
    var levelOrdinalTable = this.$el.find('#level-ordinal-column').find(':selected').closest('optgroup').prop('label');
    var levelOrdinalColumn = this.$el.find('#level-ordinal-column').val();
    var id_dimension = $currentTarget.data('iddimension');
    var id_hierarchy = $currentTarget.data('idhierarchy');
    var alertMsg = '';
    var data = [];
    var dimensionCollection;
    var hierarchyCollection;
    var $level;

    if (_.isEmpty(levelName)) {
      alertMsg += '<li>The Level Name field can not be empty!</li>';
    }
    if (_.isEmpty(levelSourceTable)) {
      alertMsg += '<li>You have to choose a Source Table for the level!</li>';
    }
    if (_.isEmpty(levelSourceColumn)) {
      alertMsg += '<li>You have to choose a Source Column for the level!</li>';
    }
    if (alertMsg !== '') {
      (new WarningModal({
        title: '<span class="i18n">Required Fields</span>',
        message: '<ul>' + alertMsg + '</ul>'
      })).render().open();

      this.set_modal_title();
    }
    else {
      data.push({
        dimension: {
          id: id_dimension
        },
        hierarchy: {
          id: id_hierarchy
        },
        level: {
          id: _.uniqueId('id_level_'),
          name: levelName,
          properties: {
            sourceTable: levelSourceTable,
            sourceColumn: levelSourceColumn,
            uniqueMember: levelUniqueMember,
            ordinalTable: levelOrdinalTable,
            ordinalColumn: levelOrdinalColumn
          }
        }
      });

      dimensionCollection = dimensionsCollection.get(id_dimension);
      hierarchyCollection = dimensionCollection.hierarchy.get(id_hierarchy);
      hierarchyCollection.level.add(new SchemaEditorLevelModel(data[0].level));

      data[0].spriteexpanded = this.$el.find('.btn-level').data('spriteexpanded');
      $level = this.level_template(data);

      this.$el.find('.parent_dimension')
        .find('.hierarchy_tree')
        .find('.hierarchy-item.selected')
        .closest('.parent_hierarchy')
        .find('.level_tree')
        .append($level);
      this.clear_form_level();

      // console.log(JSON.stringify(this.schemaModel.toJSON()));
    }
  },

  edit_level: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var dimensionsCollection = this.schemaModel.get('dimensions');
    var levelName = this.$el.find('#level-name').val();
    var levelSourceTable = this.$el.find('#level-source-table').val();
    var levelSourceColumn = this.$el.find('#level-source-column').val();
    var levelUniqueMember = this.$el.find('#level-unique-members').is(':checked');
    var levelOrdinalTable = this.$el.find('#level-ordinal-column').find(':selected').closest('optgroup').prop('label');
    var levelOrdinalColumn = this.$el.find('#level-ordinal-column').val();
    var id_dimension = $currentTarget.data('iddimension');
    var id_hierarchy = $currentTarget.data('idhierarchy');
    var id_level = $currentTarget.data('id');
    var alertMsg = '';
    var data = [];
    var dimensionCollection;
    var hierarchyCollection;
    var levelCollection;

    if (_.isEmpty(levelName)) {
      alertMsg += '<li>The Level Name field can not be empty!</li>';
    }
    if (_.isEmpty(levelSourceTable)) {
      alertMsg += '<li>You have to choose a Source Table for the level!</li>';
    }
    if (_.isEmpty(levelSourceColumn)) {
      alertMsg += '<li>You have to choose a Source Column for the level!</li>';
    }
    if (alertMsg !== '') {
      (new WarningModal({
        title: '<span class="i18n">Required Fields</span>',
        message: '<ul>' + alertMsg + '</ul>'
      })).render().open();

      this.set_modal_title();
    }
    else {
      data.push({
        name: levelName,
        properties: {
          sourceTable: levelSourceTable,
          sourceColumn: levelSourceColumn,
          uniqueMember: levelUniqueMember,
          ordinalTable: levelOrdinalTable,
          ordinalColumn: levelOrdinalColumn
        }
      });

      dimensionCollection = dimensionsCollection.get(id_dimension);
      hierarchyCollection = dimensionCollection.hierarchy.get(id_hierarchy);
      levelCollection = hierarchyCollection.level.get(id_level);
      levelCollection.set(data[0]);

      this.$el.find('.parent_dimension')
        .find('.hierarchy_tree')
        .find('.level_tree')
        .find('.level-item.selected')
        .find('.level-item-name')
        .text(data[0].name);

      this.disabled_btn_icons();
      this.unselect_current_selected_item();
      this.$el.find('.form-properties').empty();

      // console.log(JSON.stringify(this.schemaModel.toJSON()));
    }
  },

  show_delete_level: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);
    var levelName = this.$el.find('#level-name').val();

    this.id_dimension = $currentTarget.data('iddimension');
    this.id_hierarchy = $currentTarget.data('idhierarchy');
    this.id_level = $currentTarget.data('id');

    (new WarningModal({
      title: '<span class="i18n">Delete Level</span>',
      message: '<span class="i18n">You want to delete this level</span> <b>' + levelName + '</b>?',
      okay: this.delete_level,
      okayobj: this
    })).render().open();

    this.set_modal_title();
  },

  delete_level: function(args) {
    var dimensionsCollection = args.schemaModel.get('dimensions');
    var dimensionCollection;
    var hierarchyCollection;

    dimensionCollection = dimensionsCollection.get(args.id_dimension);
    hierarchyCollection = dimensionCollection.hierarchy.get(args.id_hierarchy);
    hierarchyCollection.level.remove(args.id_level);

    args.$el.find('.parent_dimension')
      .find('.hierarchy_tree')
      .find('.level_tree')
      .find('.level-item.selected')
      .closest('.parent_level')
      .remove();

    args.disabled_btn_icons();
    args.unselect_current_selected_item();
    args.$el.find('.form-properties').empty();

    // console.log(JSON.stringify(args.schemaModel.toJSON()));
  },

  call_show_delete: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);

    if (!($currentTarget.hasClass('disabled'))) {
      this.$el.find('.form-properties').find('.btn-danger').click();
    }
  },

  show_clear_model: function(event) {
    event.preventDefault();

    var $currentTarget = $(event.currentTarget);

    if (!($currentTarget.hasClass('disabled'))) {
      (new WarningModal({
        title: '<span class="i18n">Clear Model</span>',
        message: '<span class="i18n">Would you like to clear this model?</span>',
        okay: this.clear_model,
        okayobj: this
      })).render().open();

      this.set_modal_title();
    }
  },

  clear_model: function(args) {
    var tablesCollection = args.schemaModel.get('tables');
    var measuresCollection = args.schemaModel.get('measures');
    var dimensionsCollection = args.schemaModel.get('dimensions');

    tablesCollection.reset();
    measuresCollection.reset();
    dimensionsCollection.reset();

    args.disabled_btn_icons();
    args.unselect_current_selected_item();
    args.$el.find('.form-properties').empty();
    args.$el.find('.parent_measures').empty();
    args.$el.find('.parent_dimensions').empty();

    // console.log(JSON.stringify(args.schemaModel.toJSON()));
  },

  save: function(event) {
    event.preventDefault();

    var self = this;

    // console.log(JSON.stringify(this.schemaModel.toJSON()));

    this.schemaModel.save({}, {
      data: JSON.stringify(this.schemaModel.toJSON()),
      contentType: 'application/json',
      success: function() {
        self.$el.dialog('close');
      },
      error: function(data, textStatus) {
        (new WarningModal({
          title: '<span class="i18n">Warning</span>',
          message: '<h3>Error to create the Schema!</h3>'
        })).render().open();

        self.set_modal_title();

        console.error(data);
        console.error(textStatus);
      }
    });
  },

  debug: function(event) {
    event.preventDefault();
    console.log(JSON.stringify(this.schemaModel.toJSON()));
  }
});
