/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2016
 */

var SchemaEditorSchemaMock = (function() {
  'use strict';

  function SchemaEditorSchemaMock(data, opts) {
    // enforces new
    if (!(this instanceof SchemaEditorSchemaMock)) {
      return new SchemaEditorSchemaMock(data, opts);
    }
  }

  function capitalize(str) {
    if (_.isString(str)) {
      str = str.replace(/[^a-zA-Z 0-9]/gi, ' ');
      return str.charAt(0).toUpperCase() + str.substring(1).toLowerCase();
    }
  }

  function replaceMeasureAggregationColumn(columnName) {
    var measureName;
    var measureRegexp;
    var measureAggRegexp;

    if (!!columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_COLUMN) &&
        !!columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_AGGREGATION_COLUMN)) {

      measureRegexp = columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_COLUMN);
      measureAggRegexp = columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_AGGREGATION_COLUMN);
      measureName = Saiku.replaceString(measureRegexp[0], '', columnName);
      measureName = Saiku.replaceString(measureAggRegexp[0], '', measureName);

      return measureName;
    }
    else if (!!columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_COLUMN)) {
      measureRegexp = columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_COLUMN);
      measureName = Saiku.replaceString(measureRegexp[0], '', columnName);

      return measureName;
    }
    else {
      return columnName;
    }
  }

  function getMeasureAggregationColumn(columnName) {
    var agg = {
      '_sum': 'sum',
      '_avg': 'average',
      '_min': 'minimum',
      '_max': 'maximum',
      '_count': 'count',
      '_count_distinct': 'count-distinct'
    };
    var measureAggRegexp;

    if (!!columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_COLUMN) &&
        !!columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_AGGREGATION_COLUMN)) {

      measureAggRegexp = columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_AGGREGATION_COLUMN);

      return agg[measureAggRegexp[0]];
    }
    else {
      return 'sum';
    }
  }

  SchemaEditorSchemaMock.prototype.schemaTable = function(data) {
    var mockTable = {
      id: data.id || _.uniqueId('id_table_'),
      name: data.name,
      sourceTable: data.name,
      keyColumn: data.attribute.length > 0 ? data.attribute[0] : '',
      linkTarget: '',
      linkTargetColumn: ''
    };

    return mockTable;
  };

  SchemaEditorSchemaMock.prototype.schemaMeasure = function(columnName) {
    var mockMeasure = {
      id: _.uniqueId('id_measure_'),
      name: capitalize(replaceMeasureAggregationColumn(columnName)),
      properties: {
        sourceColumn: columnName,
        defaultAggregation: getMeasureAggregationColumn(columnName)
      }
    };

    return mockMeasure;
  };

  SchemaEditorSchemaMock.prototype.schemaDimension = function(data) {
    var mockDimension = {
      dimension: {
        id: data.id || _.uniqueId('id_dimension_'),
        name: capitalize(data.name),
        key: data.key || '',
        factLinkColumn: data.factLinkColumn || ''
      }
    };

    if (data && data.attribute) {
      mockDimension.attributes = this.schemaAttributes(data);
    }

    return mockDimension;
  };

  SchemaEditorSchemaMock.prototype.schemaAttributes = function(data) {
    var len = data.attribute.length;
    var mockAttributes = [];

    for (var i = 0; i < len; i++) {
      if (_.isString(data.attribute[i])) {
        mockAttributes.push({
          id: _.uniqueId('id_attr_'),
          name: capitalize(data.attribute[i]),
          sourceTable: data.name,
          sourceColumn: data.attribute[i],
          visible: true
        });
      }
      else {
        mockAttributes.push({
          id: data.attribute[i].id || _.uniqueId('id_attr_'),
          name: capitalize(data.attribute[i].name),
          sourceTable: data.attribute[i].sourceTable,
          sourceColumn: data.attribute[i].sourceColumn,
          visible: data.attribute[i].visible || false
        });
      }
    }

    return mockAttributes;
  };

  SchemaEditorSchemaMock.prototype.schemaHierarchy = function(data) {
    var mockHierarchy = {
      id: data.id || _.uniqueId('id_hierarchy_'),
      name: data.name || _.uniqueId('hierarchy_')
    };

    return mockHierarchy;
  };

  SchemaEditorSchemaMock.prototype.schemaLevel = function(data) {
    var mockLevel = {
      id: data.id || _.uniqueId('id_level_'),
      name: data.name || _.uniqueId('level_'),
      properties: {
        sourceTable: data.properties.sourceTable || '',
        sourceColumn: data.properties.sourceColumn || data.name,
        uniqueMember: data.properties.uniqueMember || false,
        ordinalTable: data.properties.ordinalTable || '',
        ordinalColumn: data.properties.ordinalColumn || ''
      }
    };

    return mockLevel;
  };

  SchemaEditorSchemaMock.prototype.getSchema = function(data) {
    var self = this;
    var schema = {
      tables: [],
      measures: [],
      dimensions: []
    };
    var tableData = {
      name: '',
      attribute: []
    };

    _.each(data, function(table, tableName) {
      _.each(table, function(column) {
        tableData.attribute.push(column.name);
      });

      tableData.name = tableName;

      schema.tables.push(self.schemaTable(tableData));

      if (tableName.indexOf('agg_') !== 0) {
        schema.dimensions.push(self.schemaDimension(tableData));
      }
    });

    // console.log(schema);

    return schema;
  };

  return SchemaEditorSchemaMock;
}());
